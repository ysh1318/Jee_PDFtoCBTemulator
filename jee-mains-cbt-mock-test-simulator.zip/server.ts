/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

/**
 * Executes a generateContent call to Gemini with a robust exponential backoff retry mechanism.
 * This is designed to gracefully handle transient network drops, rate limits (429), and socket timeouts (ECONNRESET).
 */
async function generateContentWithRetry(ai: any, params: any, maxRetries = 3, initialDelay = 3000) {
  let attempt = 0;
  while (attempt < maxRetries) {
    try {
      console.log(`Sending content generation request to Gemini (Attempt ${attempt + 1}/${maxRetries})...`);
      const response = await ai.models.generateContent(params);
      return response;
    } catch (error: any) {
      attempt++;
      console.error(`Gemini API error on attempt ${attempt}:`, error);
      
      const errorMessage = error?.message || "";
      const errorCause = error?.cause?.message || error?.cause?.code || "";
      const errorString = String(error);

      const isTransient = 
        errorMessage.includes("ECONNRESET") ||
        errorMessage.includes("fetch failed") ||
        errorMessage.includes("429") ||
        errorMessage.includes("ResourceExhausted") ||
        errorMessage.includes("503") ||
        errorMessage.includes("socket hang up") ||
        errorCause.includes("ECONNRESET") ||
        errorCause.includes("fetch failed") ||
        errorString.includes("ECONNRESET") ||
        errorString.includes("fetch failed") ||
        errorString.includes("socket hang up");

      if (isTransient && attempt < maxRetries) {
        const delay = initialDelay * Math.pow(2, attempt - 1);
        console.log(`Transient network or rate-limiting issue detected. Retrying in ${delay}ms...`);
        await new Promise((resolve) => setTimeout(resolve, delay));
      } else {
        throw error;
      }
    }
  }
  throw new Error("Failed to generate content after maximum retries.");
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Crucial: Set body parser limits to support base64 PDF payloads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // Initialize Gemini Client
  const apiKey = process.env.GEMINI_API_KEY;
  let ai: GoogleGenAI | null = null;

  if (apiKey) {
    ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }

  // Health route
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", geminiConfigured: !!apiKey });
  });

  // PDF Mock Test Parsing Endpoint
  app.post("/api/parse-pdf", async (req, res) => {
    try {
      const { pdfData, filename, subject, prefix } = req.body;

      if (!pdfData) {
        res.status(400).json({ error: "No PDF data provided" });
        return;
      }

      // Check for user-provided custom Gemini API key in headers
      const customApiKey = req.headers["x-gemini-api-key"] || req.body.customApiKey;
      let activeAiClient = ai;

      if (customApiKey && typeof customApiKey === "string" && customApiKey.trim() !== "") {
        console.log("Using custom student-provided Gemini API key for parsing.");
        activeAiClient = new GoogleGenAI({
          apiKey: customApiKey.trim(),
          httpOptions: {
            headers: {
              "User-Agent": "aistudio-build",
            },
          },
        });
      }

      if (!activeAiClient) {
        res.status(500).json({
          error: "No Gemini API key available. Please configure a default key in environment secrets, or provide a custom API key in the application settings.",
        });
        return;
      }

      console.log(`Starting PDF parsing for file: ${filename || "unnamed.pdf"}, Subject: ${subject || "All"}`);

      // Prepare standard parsing prompt
      let prompt = "";
      if (subject) {
        prompt = `You are an expert JEE Mains question paper parser. 
Analyze the attached JEE Mains Mock Test PDF and extract ONLY the questions belonging to ${subject.toUpperCase()}.

JEE Main 2026 structure for ${subject}:
- Section A: Multiple Choice Questions (MCQ) - exactly 20 questions (numbered 1 to 20), each with exactly 4 options.
- Section B: Numerical Answer Type (NAT) - exactly 5 questions (numbered 21 to 25), with no options (student inputs a numeric decimal or integer).

Your strict rules:
1. Convert all mathematical equations, scientific formulas, stoichiometry equations, variables, physical units, vectors, integrals, and coordinate layouts to pristine LaTeX representations. Wrap inline math with a single "$" (e.g. "$x^2 + y^2 = r^2$") and block display math with double "$$" (e.g. "$$\\int_0^\\infty e^{-x^2} dx = \\frac{\\sqrt{\\pi}}{2}$$").
2. If a question describes a physical setup, diagram, circuit, or chemical structure, enrich the question text with a clear, readable text-based or schematic description of that diagram so the user has the topological context to solve it!
3. For Section A questions, extract exactly 4 options. LaTeX-ify the equations in options as well. Do not include indexing like '(1)', '(A)', 'a.', etc. in the option text.
4. Deduce the correctAnswer:
   - For MCQs: MUST be "A", "B", "C", or "D".
   - For NATs: MUST be a strict numerical string (e.g. "45", "12.5", "-3", "0.5").
5. Map each question to a unique ID with the prefix '${prefix}-' (e.g. ${prefix}-01, ${prefix}-02 through ${prefix}-25).
6. Determine the 'topic' (e.g. "Electrostatics", "Chemical Bonding", "Matrices") and 'difficulty' ("Easy", "Medium", "Hard") of the question.
7. Provide a clear, detailed, step-by-step 'explanation' containing calculations and theory, formatted with LaTeX.

Extract and return up to 25 questions for ${subject} if found in the file. If no questions for this subject are present, return an empty array under "questions".`;
      } else {
        prompt = `You are an expert JEE Mains question paper parser. 
Analyze the attached JEE Mains Mock Test PDF and extract ALL questions.
Organize them systematically by their Subject (Physics, Chemistry, Mathematics).

Categorize each question into:
- Section A: Multiple Choice Questions (MCQ) - exactly 4 options.
- Section B: Numerical Answer Type (NAT) - no options.

Your instructions are:
1. Convert all mathematical equations, scientific formulas, equations, units, and chemical reactants/products to pristine LaTeX representations. Wrap inline math with a single "$" (e.g. "$x^2 + y^2 = r^2$") and block display math with double "$$" (e.g. "$$\\int_0^\\infty e^{-x^2} dx = \\frac{\\sqrt{\\pi}}{2}$$").
2. If a question describes a physical setup, diagram, circuit, or chemical structure, please enrich the question text with a clear, readable text-based or schematic description of that diagram so the user has the coordinate/topological context to solve it!
3. For Section A questions, extract exactly 4 options. LaTeX-ify the equations in options as well. Do not include indexing like '(1)', '(A)', 'a.', etc. in the option text.
4. Deduce the correctAnswer:
   - For MCQs: MUST be "A", "B", "C", or "D".
   - For NATs: MUST be a strict numerical string (e.g. "45", "12.5", "-3", "0.5").
5. Determine the 'topic' (e.g. "Electrostatics", "Thermodynamics", "Quadratic Equations") and 'difficulty' ("Easy", "Medium", "Hard") of the question.
6. Provide a clear, detailed, step-by-step 'explanation' containing calculations and theory, formatted with LaTeX.

Return a valid JSON output obeying the structured schema. Limit response questions to a maximum of 30 questions to prevent output length overflow, maintaining top subjects balance.`;
      }

      // Define standard Schema
      const responseSchema = {
        type: Type.OBJECT,
        properties: {
          testName: {
            type: Type.STRING,
            description: "A descriptive title for this mock test extracted from the PDF",
          },
          questions: {
            type: Type.ARRAY,
            description: subject 
              ? `List of translated questions belonging to ${subject}.`
              : "List of translated questions, balancing Physics, Chemistry, and Math",
            items: {
              type: Type.OBJECT,
              properties: {
                id: {
                  type: Type.STRING,
                  description: `Unique ID representing subject and serial, e.g., ${prefix ? prefix + '-01' : 'P-01'}`,
                },
                subject: {
                  type: Type.STRING,
                  enum: ["Physics", "Chemistry", "Mathematics"],
                  description: "The subject of the question",
                },
                section: {
                  type: Type.STRING,
                  enum: ["Section A", "Section B"],
                  description: "Section A is MCQ, Section B is Numerical Answer Type",
                },
                questionNumber: {
                  type: Type.INTEGER,
                  description: "Consecutive index of the question within that subject (usually 1 to 25)",
                },
                questionText: {
                  type: Type.STRING,
                  description: "The complete question text, including schemas and LaTeX math",
                },
                options: {
                  type: Type.ARRAY,
                  description: "Exactly 4 options for Section A (MCQs). Keep empty/omit for Section B",
                  items: {
                    type: Type.STRING,
                  },
                },
                correctAnswer: {
                  type: Type.STRING,
                  description: "Correct option ('A', 'B', 'C', 'D') for Section A, or correct numerical answer for Section B (e.g., '5' or '12.4')",
                },
                topic: {
                  type: Type.STRING,
                  description: "Detailed syllabus topic/chapter, e.g. 'Electrostatics' or 'Chemical Equilibrium'",
                },
                difficulty: {
                  type: Type.STRING,
                  enum: ["Easy", "Medium", "Hard"],
                  description: "Perceived difficulty level of this question",
                },
                explanation: {
                  type: Type.STRING,
                  description: "Detailed step-by-step solution utilizing LaTeX",
                },
              },
              required: [
                "id",
                "subject",
                "section",
                "questionNumber",
                "questionText",
                "correctAnswer",
                "topic",
                "difficulty",
                "explanation",
              ],
            },
          },
        },
        required: ["testName", "questions"],
      };

      // Call Gemini 3.5 Flash via our robust retry helper with structured single Content object
      const response = await generateContentWithRetry(activeAiClient, {
        model: "gemini-3.5-flash",
        contents: [
          {
            role: "user",
            parts: [
              {
                inlineData: {
                  data: pdfData,
                  mimeType: "application/pdf",
                },
              },
              {
                text: prompt,
              },
            ],
          },
        ],
        config: {
          responseMimeType: "application/json",
          responseSchema,
          temperature: 0.15, // Low temperature for factual parsing accuracy
        },
      });

      const text = response.text;
      if (!text) {
        throw new Error("No response text received from Gemini processing.");
      }

      const parsedData = JSON.parse(text.trim());
      res.json(parsedData);
    } catch (error: any) {
      console.error("PDF Parsing Error:", error);
      res.status(500).json({
        error: error.message || "Failed to process the PDF mock test.",
      });
    }
  });

  // Vite Integration
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
