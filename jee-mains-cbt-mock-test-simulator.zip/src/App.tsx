/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { GraduationCap, BookOpen, Clock, Settings, Sparkles, BookCheck } from "lucide-react";
import { Question, TestState } from "./types";
import { PdfUploader } from "./components/PdfUploader";
import { CbtEngine } from "./components/CbtEngine";
import { AnalyticsDashboard } from "./components/AnalyticsDashboard";
import { PredictorHub } from "./components/PredictorHub";
import { ParsedResultAudit } from "./components/ParsedResultAudit";

type AppStep = "UPLOAD" | "CBT" | "ANALYTICS" | "PREDICTORS";

export default function App() {
  const [step, setStep] = useState<AppStep>("UPLOAD");
  const [testName, setTestName] = useState<string>("");
  const [questions, setQuestions] = useState<Question[]>([]);
  const [testState, setTestState] = useState<TestState | null>(null);
  const [initialCbtState, setInitialCbtState] = useState<any>(null);

  // --- PARSED AUDIT & INSTRUCTION SEQUENCE ---
  const [pendingTestToAudit, setPendingTestToAudit] = useState<{ name: string; questions: Question[] } | null>(null);

  // --- SAFETY & CONFIRMATION STATES ---
  const [deletePaperId, setDeletePaperId] = useState<string | null>(null);
  const [deleteAttemptId, setDeleteAttemptId] = useState<string | null>(null);
  const [showDiscardConfirm, setShowDiscardConfirm] = useState(false);
  const [showSelfDestructConfirm, setShowSelfDestructConfirm] = useState(false);

  // --- LOCALPERSISTENCE STATE ---
  const [savedPapers, setSavedPapers] = useState<Array<{ id: string; testName: string; questions: Question[]; createdAt: string }>>(() => {
    try {
      const saved = localStorage.getItem("jee_saved_papers");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [completedAttempts, setCompletedAttempts] = useState<Array<{ id: string; testName: string; date: string; score: number; maxScore: number; testState: TestState }>>(() => {
    try {
      const saved = localStorage.getItem("jee_completed_attempts");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [activeSession, setActiveSession] = useState<{ testName: string; questions: Question[]; testState: TestState; currentSubject: any; currentQuestionId: string } | null>(() => {
    try {
      const saved = localStorage.getItem("jee_cbt_active_exam");
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Check for active session when we enter step UPLOAD
  useEffect(() => {
    if (step === "UPLOAD") {
      try {
        const saved = localStorage.getItem("jee_cbt_active_exam");
        setActiveSession(saved ? JSON.parse(saved) : null);
      } catch {
        setActiveSession(null);
      }
    }
  }, [step]);

  // Safety alert before unload on public devices
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      const hasKeys = localStorage.getItem("user_gemini_api_key") || 
                      localStorage.getItem("user_openai_api_key") ||
                      localStorage.getItem("user_anthropic_api_key") ||
                      localStorage.getItem("user_groq_api_key");
      const hasPapers = localStorage.getItem("jee_saved_papers");
      if (hasKeys || hasPapers) {
        e.preventDefault();
        e.returnValue = "Public Security Check: Please make sure you wipe all your stored API keys and mock histories before closing the tab if you are on a school or library device.";
        return e.returnValue;
      }
    };
    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, []);

  const handleTestLoaded = (name: string, loadedQuestions: Question[]) => {
    // Hold load start sequence and prompt with parsing audit pop up / instructions first!
    setPendingTestToAudit({ name, questions: loadedQuestions });

    // Save this extracted paper to Saved Papers list if it isn't already there!
    setSavedPapers((prev) => {
      const exists = prev.some((p) => p.testName.trim().toLowerCase() === name.trim().toLowerCase());
      if (exists) return prev;

      const newPaper = {
        id: String(Date.now()),
        testName: name,
        questions: loadedQuestions,
        createdAt: new Date().toLocaleDateString("en-IN", {
          day: "numeric",
          month: "short",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit",
        }),
      };
      const updated = [newPaper, ...prev].slice(0, 8); // Keep up to 8 saved papers
      try {
        localStorage.setItem("jee_saved_papers", JSON.stringify(updated));
      } catch (e) {
        console.warn("Could not save paper to localStorage:", e);
      }
      return updated;
    });
  };

  const handleTestSubmitted = (state: TestState) => {
    setTestState(state);
    setStep("ANALYTICS");
    setActiveSession(null);
    try {
      localStorage.removeItem("jee_cbt_active_exam");
    } catch {}

    // Calculate candidate score (+4 for correct, -1 for incorrect, 0 for unattempted)
    let score = 0;
    state.questions.forEach((q) => {
      const resp = state.userResponses[q.id];
      if (resp !== undefined && resp !== null && String(resp).trim() !== "") {
        if (String(resp).trim().toUpperCase() === String(q.correctAnswer).trim().toUpperCase()) {
          score += 4;
        } else {
          score -= 1;
        }
      }
    });

    setCompletedAttempts((prev) => {
      const newAttempt = {
        id: String(Date.now()),
        testName: state.testName,
        date: new Date().toLocaleDateString("en-IN", {
          day: "numeric",
          month: "short",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit",
        }),
        score,
        maxScore: state.questions.length * 4,
        testState: state,
      };
      const updated = [newAttempt, ...prev].slice(0, 15); // Store recent 15 attempts
      try {
        localStorage.setItem("jee_completed_attempts", JSON.stringify(updated));
      } catch (e) {
        console.warn("Could not save attempt history to localStorage:", e);
      }
      return updated;
    });
  };

  const handleRestart = () => {
    setQuestions([]);
    setTestName("");
    setTestState(null);
    setInitialCbtState(null);
    setStep("UPLOAD");
  };

  // --- ACTIONS ---
  const handleLoadSavedPaper = (paper: { testName: string; questions: Question[] }) => {
    setPendingTestToAudit({ name: paper.testName, questions: paper.questions });
  };

  const handleDeleteSavedPaper = (id: string) => {
    setSavedPapers((prev) => {
      const updated = prev.filter((p) => p.id !== id);
      try {
        localStorage.setItem("jee_saved_papers", JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  const handleReviewPastAttempt = (attempt: { testState: TestState }) => {
    setTestState(attempt.testState);
    setStep("ANALYTICS");
  };

  const handleDeletePastAttempt = (id: string) => {
    setCompletedAttempts((prev) => {
      const updated = prev.filter((a) => a.id !== id);
      try {
        localStorage.setItem("jee_completed_attempts", JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  const handleResumeActiveSession = () => {
    if (activeSession) {
      setTestName(activeSession.testName);
      setQuestions(activeSession.questions);
      setInitialCbtState(activeSession.testState); // pass saved response progress map
      setStep("CBT");
    }
  };

  const handleDiscardActiveSession = () => {
    try {
      localStorage.removeItem("jee_cbt_active_exam");
    } catch {}
    setActiveSession(null);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between select-none">
      {/* GLOBAL BANNER HEADER WITH DUAL-LAYER NAVIGATION */}
      {step !== "CBT" && (
        <div className="flex flex-col shrink-0 sticky top-0 z-50 shadow-md">
          <header className="bg-[#1a3a5f] border-b border-slate-700/60 px-6 py-4 flex items-center justify-between select-none text-white">
            <div className="flex items-center gap-3">
              <div className="bg-white p-1 rounded-sm shrink-0 shadow-sm">
                <div className="w-9 h-9 bg-blue-100 flex items-center justify-center text-[#1a3a5f] font-bold text-[10px] leading-tight text-center italic font-sans">
                  JEE<br />MAIN
                </div>
              </div>
              <div className="text-left leading-normal">
                <h1 className="font-bold text-sm tracking-tight text-white uppercase flex items-center gap-1.5">
                  <span>Joint Entrance Examination</span>
                  <span className="text-[10px] text-blue-200 bg-blue-900/40 px-1.5 py-0.5 rounded border border-blue-500/30 font-bold font-mono uppercase tracking-wide">CBT Simulator</span>
                </h1>
                <p className="text-[10px] text-slate-300 opacity-80 uppercase tracking-widest leading-none mt-1">PDF-to-Test AI Calibration & Simulator</p>
              </div>
            </div>

            <div className="flex items-center gap-4 text-xs font-semibold text-slate-200">
              <button
                onClick={() => setShowSelfDestructConfirm(true)}
                className="px-3 py-1.5 bg-[#e11d48]/10 hover:bg-[#e11d48]/20 border border-[#e11d48]/40 hover:border-[#e11d48]/60 text-red-200 hover:text-white rounded-lg text-[11px] font-bold cursor-pointer transition flex items-center gap-1.5 shadow-2xs"
                title="Wipe cached keys and credentials on library computer"
              >
                <span>🔒 Public Device Safety Clean</span>
              </button>
              <div className="hidden md:flex items-center gap-1.5 opacity-90">
                <Sparkles size={14} className="text-amber-300 animate-pulse" />
                <span>Full Stack Powered by Gemini AI</span>
              </div>
            </div>
          </header>

          {/* SECONDARY NAVIGATION BAR */}
          <nav className="bg-white border-b border-slate-200 py-2 px-6 flex items-center justify-between gap-4 select-none">
            <div className="flex items-center gap-1 overflow-x-auto scrollbar-none py-0.5">
              <button
                type="button"
                onClick={() => setStep("UPLOAD")}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition shrink-0 cursor-pointer ${
                  step === "UPLOAD"
                    ? "bg-[#1a3a5f]/10 text-[#1a3a5f] font-extrabold"
                    : "text-slate-500 hover:text-slate-800 hover:bg-slate-50"
                }`}
              >
                <span>📝 Practice & Upload Hub</span>
              </button>
              
              <button
                type="button"
                onClick={() => {
                  if (!testState && completedAttempts.length > 0) {
                    setTestState(completedAttempts[0].testState);
                  }
                  setStep("ANALYTICS");
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition shrink-0 cursor-pointer ${
                  step === "ANALYTICS"
                    ? "bg-[#1a3a5f]/10 text-[#1a3a5f] font-extrabold"
                    : "text-slate-500 hover:text-slate-800 hover:bg-slate-50"
                }`}
              >
                <span>📊 Growth Analytics</span>
              </button>

              <button
                type="button"
                onClick={() => setStep("PREDICTORS")}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition shrink-0 cursor-pointer ${
                  step === "PREDICTORS"
                    ? "bg-[#1a3a5f]/10 text-[#1a3a5f] font-extrabold"
                    : "text-slate-500 hover:text-slate-800 hover:bg-slate-50"
                }`}
              >
                <span>🔮 Predictor & JoSAA Hub</span>
                <span className="text-[8px] bg-emerald-100 text-emerald-800 font-black px-1.5 py-0.5 rounded-full animate-pulse">New</span>
              </button>
            </div>

            {/* Quick stats indicators */}
            <div className="hidden sm:flex items-center gap-3 text-[11px] font-bold text-slate-500 font-mono">
              <div className="flex items-center gap-1 text-[#1a3a5f]">
                <span>📚</span>
                <span>Library: <strong className="text-slate-700 font-black">{savedPapers.length} Mocks</strong></span>
              </div>
              <span className="text-slate-300">|</span>
              <div className="flex items-center gap-1 text-indigo-750">
                <span>🏆</span>
                <span>Attempts: <strong className="text-slate-700 font-black">{completedAttempts.length} Reports</strong></span>
              </div>
            </div>
          </nav>
        </div>
      )}

      {/* CORE VIEW MODULE */}
      <main className="flex-1 w-full flex flex-col justify-center">
        {step === "UPLOAD" && (
          <div className="animate-fade-in py-6">
            
            {/* ACTIVE EXAMINATION RECOVERY BANNER */}
            {activeSession && (
              <div className="max-w-6xl w-full mx-auto mb-6 bg-amber-50 border border-amber-200 rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm animate-pulse select-none text-left">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center text-amber-700 font-bold shrink-0">
                    📝
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-amber-800 uppercase tracking-wider">Unfinished Offline Session Found</h4>
                    <p className="font-bold text-slate-800 text-sm mt-0.5">{activeSession.testName}</p>
                    <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-2">
                      <span>⏰ Time Left: <span className="font-mono font-bold text-slate-700">{Math.floor(activeSession.testState.timeLeft / 60)} mins</span></span>
                      <span>•</span>
                      <span>💼 Extracted: <span className="font-bold text-slate-700">{activeSession.questions.length} Questions</span></span>
                    </p>
                  </div>
                </div>
                <div className="flex gap-2 shrink-0 select-none items-center">
                  <button
                    onClick={handleResumeActiveSession}
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-700 cursor-pointer text-white font-bold text-xs rounded transition flex items-center gap-1.5 shadow-md shadow-amber-600/10"
                  >
                    <span>Resume Live Exam</span>
                    <span>→</span>
                  </button>
                  {!showDiscardConfirm ? (
                    <button
                      onClick={() => setShowDiscardConfirm(true)}
                      className="px-3 py-2 bg-white hover:bg-slate-50 border border-slate-300 text-xs font-bold text-slate-600 rounded cursor-pointer transition w-20"
                    >
                      Discard
                    </button>
                  ) : (
                    <div className="flex items-center gap-1.5 bg-red-50 border border-red-200 px-2 py-1 rounded-lg">
                      <span className="text-[10px] font-extrabold text-red-600 uppercase">Sure?</span>
                      <button
                        onClick={() => {
                          handleDiscardActiveSession();
                          setShowDiscardConfirm(false);
                        }}
                        className="px-2 py-1 bg-red-600 hover:bg-red-700 text-white font-extrabold text-[10px] rounded cursor-pointer transition"
                      >
                        Yes
                      </button>
                      <button
                        onClick={() => setShowDiscardConfirm(false)}
                        className="px-2 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-[10px] rounded cursor-pointer transition"
                      >
                        No
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}

            <PdfUploader onTestLoaded={handleTestLoaded} />

            {/* PUBLIC DEVICE GUARD HUD ON HOME SCREEN */}
            <div className="max-w-6xl w-full mx-auto mt-6 px-4 select-none">
              <div className="bg-linear-to-r from-slate-50 to-slate-100/50 p-4 rounded-xl border border-slate-200/80 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-4 text-left">
                <div className="flex items-center gap-3">
                  <span className="text-xl shrink-0">🛡️</span>
                  <div>
                    <h4 className="font-extrabold text-slate-800 text-xs tracking-wide uppercase flex items-center gap-1.5">
                      <span>Public Device Guard</span>
                      <span className="text-[9px] bg-[#1a3a5f]/10 text-[#1a3a5f] px-1.5 rounded-full uppercase font-mono font-black">Armed</span>
                    </h4>
                    <p className="text-[11px] text-slate-500 font-semibold leading-relaxed mt-0.5">
                      Are you practicing using a shared classroom, school, or library computer? Clear your secrets instantly before logging off.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowSelfDestructConfirm(true)}
                  className="px-4 py-2 bg-red-50 hover:bg-red-100 text-red-700 border border-red-250 font-bold text-xs rounded-lg transition hover:scale-[1.01] cursor-pointer flex items-center gap-1.5 shrink-0"
                >
                  <span>🧹 Wipe All Local Data</span>
                </button>
              </div>
            </div>

            {/* OFFLINE LOCAL LIBRARY SECTION */}
            {(savedPapers.length > 0 || completedAttempts.length > 0) && (
              <div className="max-w-6xl w-full mx-auto mt-8 border-t border-slate-200 pt-8 text-left select-none pb-12 w-full px-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  
                  {/* COLUMN 1: SAVED MOCK PAPERS (FREE TIER RESOLVER) */}
                  {savedPapers.length > 0 && (
                    <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col">
                      <div className="flex items-center justify-between border-b pb-3 mb-4">
                        <div>
                          <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-1.5">
                            <BookCheck size={16} className="text-emerald-600" />
                            <span>CBT Mock Paper Library</span>
                          </h3>
                          <p className="text-[10px] text-slate-400 font-semibold mt-0.5">Saved locally (never spends quota again)</p>
                        </div>
                        <span className="text-[10px] bg-emerald-50 text-emerald-700 font-bold px-2 py-0.5 rounded-full border border-emerald-100">
                          {savedPapers.length} Papers
                        </span>
                      </div>

                      <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
                        {savedPapers.map((paper) => (
                          <div 
                            key={paper.id} 
                            onClick={() => handleLoadSavedPaper(paper)}
                            className="group flex items-center justify-between p-3 rounded-lg border border-slate-100 bg-slate-50 hover:bg-slate-100/70 hover:border-blue-200 cursor-pointer transition"
                          >
                            <div className="flex items-center gap-3 min-w-0 flex-1">
                              <div className="w-8 h-8 rounded bg-blue-50 text-[#1a3a5f] font-black text-[10px] flex items-center justify-center border border-blue-100 group-hover:bg-blue-600 group-hover:text-white transition">
                                PDF
                              </div>
                              <div className="min-w-0 flex-1">
                                <p className="font-bold text-slate-700 text-xs truncate group-hover:text-[#1a3a5f] transition">{paper.testName}</p>
                                <p className="text-[10px] text-slate-400 mt-1 flex items-center gap-1.5 font-semibold">
                                  <span>{paper.createdAt}</span>
                                  <span>•</span>
                                  <span className="text-[#1a3a5f] font-bold">{paper.questions.length} Qs</span>
                                </p>
                              </div>
                            </div>
                            
                            <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                              {deletePaperId !== paper.id ? (
                                <>
                                  <span className="text-[10px] text-blue-600 font-bold group-hover:underline opacity-0 group-hover:opacity-100 transition mr-1 hidden sm:inline">
                                    Launch CBT
                                  </span>
                                  <button 
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setDeletePaperId(paper.id);
                                    }}
                                    className="p-1 rounded text-slate-450 hover:text-red-600 hover:bg-red-50 cursor-pointer transition text-xs"
                                    title="Delete Saved Paper"
                                  >
                                    🗑️
                                  </button>
                                </>
                              ) : (
                                <div className="flex items-center gap-1 bg-red-50 border border-red-150 p-1 rounded-sm animate-bounce">
                                  <button
                                    onClick={() => {
                                      handleDeleteSavedPaper(paper.id);
                                      setDeletePaperId(null);
                                    }}
                                    className="px-1.5 py-0.5 bg-red-600 text-white rounded text-[9.5px] font-black hover:bg-red-700 transition"
                                  >
                                    Confirm
                                  </button>
                                  <button
                                    onClick={() => setDeletePaperId(null)}
                                    className="px-1 py-0.5 bg-slate-200 text-slate-700 rounded text-[9.5px] font-bold hover:bg-slate-300 transition"
                                  >
                                    No
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* COLUMN 2: COMPLETED SCORES & SCORECARDS HISTORY */}
                  {completedAttempts.length > 0 && (
                    <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col">
                      <div className="flex items-center justify-between border-b pb-3 mb-4">
                        <div>
                          <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-1.5">
                            <GraduationCap size={16} className="text-indigo-600" />
                            <span>Past Attempt History</span>
                          </h3>
                          <p className="text-[10px] text-slate-400 font-semibold mt-0.5">Track and review previous report cards</p>
                        </div>
                        <span className="text-[10px] bg-indigo-50 text-indigo-700 font-bold px-2 py-0.5 rounded-full border border-indigo-100">
                          {completedAttempts.length} Reports
                        </span>
                      </div>

                      <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
                        {completedAttempts.map((attempt) => {
                          const accuracy = attempt.testState ? Math.round(
                            (Object.keys(attempt.testState.userResponses).filter(
                              (qId) => {
                                const qObj = attempt.testState.questions.find((q) => q.id === qId);
                                return qObj && String(attempt.testState.userResponses[qId]).trim().toUpperCase() === String(qObj.correctAnswer).trim().toUpperCase();
                              }
                            ).length / Math.max(Object.keys(attempt.testState.userResponses).length, 1)) * 100
                          ) : 0;

                          return (
                            <div 
                              key={attempt.id}
                              onClick={() => handleReviewPastAttempt(attempt)}
                              className="group flex items-center justify-between p-3 rounded-lg border border-slate-100 bg-slate-50 hover:bg-slate-100/70 hover:border-indigo-200 cursor-pointer transition"
                            >
                              <div className="flex items-center gap-3 min-w-0 flex-1">
                                <div className="w-8 h-8 rounded bg-indigo-50 text-indigo-700 font-black text-[10px] flex flex-col items-center justify-center border border-indigo-100 group-hover:bg-indigo-600 group-hover:text-white transition leading-none py-1">
                                  <span>{attempt.score}</span>
                                  <span className="text-[6px] opacity-75 mt-0.5 uppercase">PTS</span>
                                </div>
                                <div className="min-w-0 flex-1">
                                  <p className="font-bold text-slate-700 text-xs truncate group-hover:text-indigo-950 transition">{attempt.testName}</p>
                                  <p className="text-[10px] text-slate-400 font-semibold mt-1 flex items-center gap-1.5 flex-wrap">
                                    <span>{attempt.date}</span>
                                    <span>•</span>
                                    <span>Score: <span className="text-indigo-600 font-bold">{attempt.score}/{attempt.maxScore}</span></span>
                                    <span>•</span>
                                    <span>Acc: <span className="font-bold">{accuracy}%</span></span>
                                  </p>
                                </div>
                              </div>
                              
                              <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                                {deleteAttemptId !== attempt.id ? (
                                  <>
                                    <span className="text-[10px] text-indigo-600 font-bold group-hover:underline opacity-0 group-hover:opacity-100 transition mr-1 hidden sm:inline">
                                      Review
                                    </span>
                                    <button 
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setDeleteAttemptId(attempt.id);
                                      }}
                                      className="p-1 rounded text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer transition text-xs"
                                      title="Delete past history"
                                    >
                                      🗑️
                                    </button>
                                  </>
                                ) : (
                                  <div className="flex items-center gap-1 bg-red-50 border border-red-150 p-1 rounded-sm animate-bounce">
                                    <button
                                      onClick={() => {
                                        handleDeletePastAttempt(attempt.id);
                                        setDeleteAttemptId(null);
                                      }}
                                      className="px-1.5 py-0.5 bg-red-600 text-white rounded text-[9.5px] font-black hover:bg-red-700 transition"
                                    >
                                      Confirm
                                    </button>
                                    <button
                                      onClick={() => setDeleteAttemptId(null)}
                                      className="px-1 py-0.5 bg-slate-200 text-slate-700 rounded text-[9.5px] font-bold hover:bg-slate-300 transition"
                                    >
                                      No
                                    </button>
                                  </div>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                </div>
              </div>
            )}

          </div>
        )}

        {step === "CBT" && (
          <div className="h-[calc(100vh-100px)]">
            <CbtEngine
              testName={testName}
              questions={questions}
              onTestSubmit={handleTestSubmitted}
              onExit={handleRestart}
              initialState={initialCbtState}
            />
          </div>
        )}

        {step === "ANALYTICS" && testState && (
          <div className="animate-fade-in py-6">
            <AnalyticsDashboard testState={testState} onRestart={handleRestart} />
          </div>
        )}

        {step === "ANALYTICS" && !testState && (
          <div className="animate-fade-in py-12 max-w-4xl w-full mx-auto px-4 text-center">
            <div className="bg-white rounded-2xl border-2 border-slate-200 p-8 shadow-xs">
              <span className="text-4xl">📊</span>
              <h3 className="text-lg font-black text-slate-800 tracking-tight mt-3">No Active Scorecard Selected</h3>
              <p className="text-xs text-slate-550 mt-1 max-w-md mx-auto leading-relaxed">
                You haven't parsed or submitted any active mock tests during this session yet. To generate high-fidelity reports click on any past test reports in your history or head back to the practice hub.
              </p>

              {completedAttempts.length > 0 ? (
                <div className="mt-6 space-y-2 text-left max-w-lg mx-auto">
                  <span className="text-[10px] font-black uppercase text-indigo-600 tracking-widest block mb-2">Available Reports ({completedAttempts.length}):</span>
                  {completedAttempts.map((attempt) => (
                    <div
                      key={attempt.id}
                      onClick={() => setTestState(attempt.testState)}
                      className="p-3 bg-slate-50 hover:bg-indigo-50/55 border border-slate-150 hover:border-indigo-250 rounded-lg cursor-pointer flex justify-between items-center transition"
                    >
                      <div className="min-w-0">
                        <p className="text-xs font-black text-slate-700 truncate">{attempt.testName}</p>
                        <p className="text-[10px] text-slate-405 font-semibold mt-0.5">{attempt.date} • Score: {attempt.score}/{attempt.maxScore}</p>
                      </div>
                      <span className="text-[11px] font-bold text-indigo-650 shrink-0">Open Report →</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="mt-8 flex justify-center gap-3">
                  <button
                    onClick={() => setStep("UPLOAD")}
                    className="px-4 py-2 bg-[#1a3a5f] text-white font-bold text-xs rounded-lg transition shrink-0 cursor-pointer"
                  >
                    Go Upload PDF
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {step === "PREDICTORS" && (
          <div className="animate-fade-in py-2">
            <PredictorHub 
              completedAttempts={completedAttempts} 
              onSelectAttempt={(attempt) => {
                setTestState(attempt.testState);
                setStep("ANALYTICS");
              }}
              savedPapersCount={savedPapers.length}
            />
          </div>
        )}
      </main>

      {/* PUBLIC COMPUTER SAFE-WIPE MODAL */}
      {showSelfDestructConfirm && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center z-[100] p-4 select-none">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border-2 border-red-100 animate-scale-up text-left relative overflow-hidden">
            {/* Top red header stripe */}
            <div className="absolute top-0 left-0 right-0 h-2 bg-rose-600" />
            
            <div className="flex gap-4 items-start pt-2">
              <div className="w-12 h-12 rounded-full bg-rose-100 flex items-center justify-center text-rose-600 text-xl font-bold shrink-0">
                🧹
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-lg font-black text-slate-800 tracking-tight">Public Computer Security Check</h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Are you preparing on a public computer, library, classroom, or cyber cafe? Leaving your cached credentials can put your private API quotas at risk. Let's make sure everything is completely wiped clean!
                </p>
              </div>
            </div>

            <div className="my-5 bg-rose-50/50 rounded-xl border border-rose-100 p-4 space-y-3">
              <div className="text-[10px] font-black text-rose-700 uppercase tracking-widest flex items-center gap-1.5 border-b border-rose-105 pb-1.5">
                <span>⚠️ Session components to be permanently deleted:</span>
              </div>
              <ul className="text-xs text-slate-600 space-y-2 font-semibold">
                <li className="flex items-center gap-2">
                  <span className="text-rose-500 font-bold">✓</span>
                  <span><strong>All Provider API Keys</strong> (Gemini, OpenAI, Anthropic, Groq)</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-rose-500 font-bold">✓</span>
                  <span><strong>Custom Study Companions</strong> and Graphic Assets URLs</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-rose-500 font-bold">✓</span>
                  <span><strong>Saved Mock papers library</strong> cache ({savedPapers.length} items)</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-rose-500 font-bold">✓</span>
                  <span><strong>Past score report cards</strong> & Analytics records ({completedAttempts.length} report cards)</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-rose-500 font-bold">✓</span>
                  <span><strong>Unfinished test progress maps</strong> and active session cookies</span>
                </li>
              </ul>
            </div>

            <p className="text-[11px] text-slate-400 italic">
              * Note: This safely cleans 100% of local storage data. This action is instant and irreversible.
            </p>

            <div className="mt-6 flex flex-col sm:flex-row gap-2 justify-end select-none">
              <button
                type="button"
                onClick={() => {
                  try {
                    localStorage.clear();
                    window.location.reload();
                  } catch {}
                }}
                className="w-full sm:w-auto px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs rounded-lg transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer shadow-md shadow-rose-200 hover:scale-[1.01]"
              >
                <span>🧹 Wipe All My Platform Data</span>
              </button>
              <button
                type="button"
                onClick={() => setShowSelfDestructConfirm(false)}
                className="w-full sm:w-auto px-4 py-2.5 bg-slate-150 hover:bg-slate-205 text-slate-600 font-bold text-xs rounded-lg transition cursor-pointer text-center"
              >
                Cancel & Go Back
              </button>
            </div>
          </div>
        </div>
      )}

      {/* GLOBAL FOOTER (only shown outside examination engine) */}
      {step !== "CBT" && (
        <footer className="bg-white border-t border-slate-200 py-4 px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-400 text-[10px] sm:text-xs select-none shadow-[0_-1px_3px_rgba(0,0,0,0.02)]">
          <div className="flex flex-col text-left gap-0.5 max-w-xl">
            <div className="flex items-center gap-1.5 font-bold text-slate-500">
              <GraduationCap size={14} className="text-[#1a3a5f]" />
              <span>&copy; {new Date().getFullYear()} CBT Simulator. Independent Educational Tool.</span>
            </div>
            <p className="text-[10px] text-slate-400 font-medium">
              * This simulator is a custom student companion and is not affiliated with, licensed by, or connected to the National Testing Agency (NTA) in any manner.
            </p>
          </div>
          <div className="flex gap-4 font-semibold text-slate-400 shrink-0">
            <span>Prescribed Calibration Standards</span>
            <span>•</span>
            <span>MathonGo/Allen Scale Metrics</span>
          </div>
        </footer>
      )}

      {/* AI PARSED AUDIT & EXAM REGULATORY INSTRUCTIONS FLOW ONBOARDING */}
      {pendingTestToAudit && (
        <ParsedResultAudit
          testName={pendingTestToAudit.name}
          questions={pendingTestToAudit.questions}
          onProceedToTest={() => {
            const auditData = pendingTestToAudit;
            setPendingTestToAudit(null); // clear overlay
            setTestName(auditData.name);
            setQuestions(auditData.questions);
            setInitialCbtState(null);
            setStep("CBT");
            setActiveSession(null); // dismiss previous
          }}
          onCancel={() => {
            setPendingTestToAudit(null);
          }}
        />
      )}
    </div>
  );
}
