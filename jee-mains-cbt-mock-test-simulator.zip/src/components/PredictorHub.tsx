/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useRef, useEffect } from "react";
import { 
  Award, 
  MapPin, 
  BookOpen, 
  Sparkles, 
  ChevronRight, 
  Sliders, 
  Building2, 
  Search, 
  TrendingUp, 
  Compass, 
  ShieldAlert, 
  Cpu, 
  HelpCircle,
  Lightbulb,
  ArrowRight,
  Filter,
  BarChart2,
  Minimize2,
  Calendar,
  CheckCircle,
  Clock,
  Target
} from "lucide-react";
import { TestState } from "../types";

// Types for Mock attempts passed from App
interface Attempt {
  id: string;
  testName: string;
  date: string;
  score: number;
  maxScore: number;
  testState: TestState;
}

interface PredictorHubProps {
  completedAttempts: Attempt[];
  onSelectAttempt: (attempt: Attempt) => void;
  savedPapersCount: number;
}

// College Data Interface for JOSAA realistic cutoffs
interface CollegePreset {
  name: string;
  location: string;
  branch: string;
  tier: "Tier-1" | "Tier-2" | "Tier-3";
  type: "NIT" | "IIIT" | "GFTI" | "COEP";
  // JOSAA Closing CRL Rank cutoffs per category
  cutoffs: {
    General: number;
    OBC_NCL: number;
    SC: number;
    ST: number;
  };
}

// Extended curated list of top-tier engineering institutions (NTA-independent JoSAA simulated cutoffs)
const COLLEGES: CollegePreset[] = [
  // Tier-1: Premium NITs & DTU
  { name: "NIT Trichy (NITT)", location: "Tiruchirappalli, Tamil Nadu", branch: "Computer Science & Engineering", tier: "Tier-1", type: "NIT", cutoffs: { General: 5100, OBC_NCL: 15400, SC: 30100, ST: 62000 } },
  { name: "NIT Trichy (NITT)", location: "Tiruchirappalli, Tamil Nadu", branch: "Electronics & Communication Engg", tier: "Tier-1", type: "NIT", cutoffs: { General: 9200, OBC_NCL: 27000, SC: 51200, ST: 98000 } },
  { name: "NIT Trichy (NITT)", location: "Tiruchirappalli, Tamil Nadu", branch: "Mechanical Engineering", tier: "Tier-1", type: "NIT", cutoffs: { General: 16505, OBC_NCL: 48020, SC: 92000, ST: 160000 } },
  
  { name: "NIT Surathkal (NITK)", location: "Mangaluru, Karnataka", branch: "Computer Science & Engineering", tier: "Tier-1", type: "NIT", cutoffs: { General: 6125, OBC_NCL: 18100, SC: 36000, ST: 70000 } },
  { name: "NIT Surathkal (NITK)", location: "Mangaluru, Karnataka", branch: "Artificial Intelligence & Data Sci", tier: "Tier-1", type: "NIT", cutoffs: { General: 7200, OBC_NCL: 21000, SC: 42000, ST: 81000 } },
  { name: "NIT Surathkal (NITK)", location: "Mangaluru, Karnataka", branch: "Electrical & Electronics Engg", tier: "Tier-1", type: "NIT", cutoffs: { General: 12500, OBC_NCL: 37500, SC: 71000, ST: 125000 } },

  { name: "NIT Warangal (NITW)", location: "Warangal, Telangana", branch: "Computer Science & Engineering", tier: "Tier-1", type: "NIT", cutoffs: { General: 6800, OBC_NCL: 20400, SC: 39500, ST: 78000 } },
  { name: "NIT Warangal (NITW)", location: "Warangal, Telangana", branch: "Electronics & Communication Engg", tier: "Tier-1", type: "NIT", cutoffs: { General: 11000, OBC_NCL: 32550, SC: 64000, ST: 115000 } },
  
  { name: "NIT Calicut (NITC)", location: "Kozhikode, Kerala", branch: "Computer Science & Engineering", tier: "Tier-1", type: "NIT", cutoffs: { General: 10500, OBC_NCL: 31000, SC: 58000, ST: 110000 } },
  { name: "NIT Calicut (NITC)", location: "Kozhikode, Kerala", branch: "Electronics & Communication Engg", tier: "Tier-1", type: "NIT", cutoffs: { General: 15400, OBC_NCL: 45000, SC: 88000, ST: 152000 } },

  { name: "MNIT Jaipur", location: "Jaipur, Rajasthan", branch: "Computer Science & Engineering", tier: "Tier-1", type: "NIT", cutoffs: { General: 8400, OBC_NCL: 25000, SC: 48000, ST: 94000 } },
  { name: "MNNIT Allahabad", location: "Prayagraj, Uttar Pradesh", branch: "Computer Science & Engineering", tier: "Tier-1", type: "NIT", cutoffs: { General: 7100, OBC_NCL: 21500, SC: 41000, ST: 80000 } },
  { name: "VNIT Nagpur", location: "Nagpur, Maharashtra", branch: "Computer Science & Engineering", tier: "Tier-1", type: "NIT", cutoffs: { General: 9500, OBC_NCL: 28005, SC: 54000, ST: 102000 } },
  
  { name: "DTU Delhi", location: "Rohini, New Delhi", branch: "Computer Science & Engineering (COE)", tier: "Tier-1", type: "GFTI", cutoffs: { General: 12500, OBC_NCL: 38000, SC: 78000, ST: 140000 } },
  { name: "DTU Delhi", location: "Rohini, New Delhi", branch: "Information Technology (IT)", tier: "Tier-1", type: "GFTI", cutoffs: { General: 16500, OBC_NCL: 49000, SC: 92000, ST: 168000 } },
  { name: "NSUT Delhi", location: "Dwarka, New Delhi", branch: "Computer Engg (Artificial Intelligence)", tier: "Tier-1", type: "GFTI", cutoffs: { General: 11800, OBC_NCL: 36000, SC: 74000, ST: 135000 } },
  
  { name: "IIIT Allahabad (IIITA)", location: "Allahabad, Uttar Pradesh", branch: "Information Technology (IT)", tier: "Tier-1", type: "IIIT", cutoffs: { General: 5800, OBC_NCL: 18000, SC: 35000, ST: 71000 } },
  { name: "IIIT Allahabad (IIITA)", location: "Allahabad, Uttar Pradesh", branch: "Electronics & Communication Engg", tier: "Tier-1", type: "IIIT", cutoffs: { General: 11200, OBC_NCL: 33000, SC: 62000, ST: 110000 } },
  { name: "IIIT Delhi", location: "Okhla, New Delhi", branch: "Computer Science & Applied Math", tier: "Tier-1", type: "IIIT", cutoffs: { General: 15500, OBC_NCL: 45000, SC: 85000, ST: 165000 } },
  { name: "IIIT Gwalior", location: "Gwalior, Madhya Pradesh", branch: "Computer Science & Engineering", tier: "Tier-1", type: "IIIT", cutoffs: { General: 13500, OBC_NCL: 39000, SC: 78000, ST: 145000 } },

  // Tier-2: High Growth Institutes
  { name: "NIT Rourkela", location: "Rourkela, Odisha", branch: "Computer Science & Engineering", tier: "Tier-1", type: "NIT", cutoffs: { General: 8200, OBC_NCL: 24500, SC: 47000, ST: 92000 } },
  { name: "NIT Jalandhar", location: "Jalandhar, Punjab", branch: "Computer Science & Engineering", tier: "Tier-2", type: "NIT", cutoffs: { General: 16500, OBC_NCL: 49000, SC: 94000, ST: 180000 } },
  { name: "NIT Kurukshetra", location: "Kurukshetra, Haryana", branch: "Computer Science & Engineering", tier: "Tier-2", type: "NIT", cutoffs: { General: 12000, OBC_NCL: 35000, SC: 68000, ST: 130000 } },
  { name: "NIT Kurukshetra", location: "Kurukshetra, Haryana", branch: "Information Technology", tier: "Tier-2", type: "NIT", cutoffs: { General: 14500, OBC_NCL: 43000, SC: 81000, ST: 155000 } },
  { name: "NIT Silchar", location: "Silchar, Assam", branch: "Computer Science & Engineering", tier: "Tier-2", type: "NIT", cutoffs: { General: 21000, OBC_NCL: 62000, SC: 112000, ST: 210000 } },
  { name: "NIT Durgapur", location: "Durgapur, West Bengal", branch: "Computer Science & Engineering", tier: "Tier-2", type: "NIT", cutoffs: { General: 15000, OBC_NCL: 44000, SC: 84000, ST: 160000 } },
  
  { name: "MANIT Bhopal", location: "Bhopal, Madhya Pradesh", branch: "Computer Science & Engineering", tier: "Tier-1", type: "NIT", cutoffs: { General: 11000, OBC_NCL: 32000, SC: 61000, ST: 120000 } },
  { name: "SVNIT Surat", location: "Surat, Gujarat", branch: "Computer Science & Engineering", tier: "Tier-2", type: "NIT", cutoffs: { General: 14000, OBC_NCL: 41000, SC: 78000, ST: 150000 } },
  { name: "IIIT Pune", location: "Pune, Maharashtra", branch: "Computer Science & Engineering", tier: "Tier-2", type: "IIIT", cutoffs: { General: 17500, OBC_NCL: 51200, SC: 98000, ST: 190000 } },
  { name: "IIIT Lucknow", location: "Lucknow, Uttar Pradesh", branch: "Computer Science (CSE)", tier: "Tier-2", type: "IIIT", cutoffs: { General: 11500, OBC_NCL: 34000, SC: 69000, ST: 132000 } },
  { name: "IIIT Jabalpur (PDPM)", location: "Jabalpur, Madhya Pradesh", branch: "Computer Science & Engineering", tier: "Tier-2", type: "IIIT", cutoffs: { General: 15500, OBC_NCL: 46200, SC: 85200, ST: 156000 } },
  { name: "IIIT Bangalore", location: "Electronic City, Bengaluru", branch: "Integrated M.Tech Computer Science", tier: "Tier-1", type: "IIIT", cutoffs: { General: 8500, OBC_NCL: 26000, SC: 52000, ST: 104000 } },
  
  // Tier-3: Peripheral NITs & Regional Gems
  { name: "NIT Srinagar", location: "Srinagar, Jammu & Kashmir", branch: "Computer Science & Engineering", tier: "Tier-3", type: "NIT", cutoffs: { General: 32000, OBC_NCL: 94000, SC: 180000, ST: 310000 } },
  { name: "NIT Agartala", location: "Agartala, Tripura", branch: "Computer Science & Engineering", tier: "Tier-3", type: "NIT", cutoffs: { General: 29000, OBC_NCL: 86000, SC: 162000, ST: 280000 } },
  { name: "IIIT Vadodara", location: "Vadodara, Gujarat", branch: "Computer Science & Engineering", tier: "Tier-2", type: "IIIT", cutoffs: { General: 23500, OBC_NCL: 69050, SC: 130000, ST: 230000 } },
  { name: "PEC Chandigarh", location: "Chandigarh", branch: "Computer Science & Engineering", tier: "Tier-1", type: "GFTI", cutoffs: { General: 11500, OBC_NCL: 34000, SC: 66050, ST: 128000 } },
  { name: "BIT Mesra", location: "Ranchi, Jharkhand", branch: "Computer Science & Engineering", tier: "Tier-2", type: "GFTI", cutoffs: { General: 19500, OBC_NCL: 57000, SC: 110000, ST: 195000 } },
  { name: "COEP Tech University", location: "Pune, Maharashtra", branch: "Computer Engineering (MH State Code)", tier: "Tier-1", type: "COEP", cutoffs: { General: 4200, OBC_NCL: 12500, SC: 24000, ST: 51000 } },
  { name: "Jadavpur University", location: "Kolkata, West Bengal", branch: "Computer Science & Engineering", tier: "Tier-1", type: "GFTI", cutoffs: { General: 2100, OBC_NCL: 8200, SC: 19200, ST: 44000 } }
];

export function PredictorHub({ completedAttempts, onSelectAttempt, savedPapersCount }: PredictorHubProps) {
  // Navigation Tabs inside predictors
  type PredictionMode = "LATEST_SOLVE" | "OVERALL_STATS" | "CUSTOM_MANUAL";
  const [activeMode, setActiveMode] = useState<PredictionMode>(
    completedAttempts.length > 0 ? "LATEST_SOLVE" : "CUSTOM_MANUAL"
  );

  // June 2026 Shift Difficulty Normalizer (MathonGo/Allen Scale)
  // Shift difficulty shifts the score-to-percentile boundary curves!
  const [difficultyMode, setDifficultyMode] = useState<"TOUGH" | "MODERATE" | "EASY">("MODERATE");

  // States for Custom Mode (Mode 3)
  const [customInputType, setCustomInputType] = useState<"SCORE" | "PERCENTILE" | "RANK">("SCORE");
  const [customScoreValue, setCustomScoreValue] = useState<number>(160);
  const [customPercentileValue, setCustomPercentileValue] = useState<number>(98.5);
  const [customRankValue, setCustomRankValue] = useState<number>(21000);
  const [customCategory, setCustomCategory] = useState<"General" | "OBC_NCL" | "SC" | "ST">("General");
  
  // Interactive SVG Graph State (cursor coordinates)
  const [hoveredPoint, setHoveredPoint] = useState<{ score: number, percentile: number } | null>(null);
  const graphContainerRef = useRef<SVGSVGElement | null>(null);

  // States for search and college filtering
  const [searchCollegeQuery, setSearchCollegeQuery] = useState("");
  const [tierFilter, setTierFilter] = useState<"All" | "Tier-1" | "Tier-2" | "Tier-3">("All");
  const [typeFilter, setTypeFilter] = useState<"All" | "NIT" | "IIIT" | "GFTI">("All");

  // Mode 1 evaluation (Latest mock solving results)
  const latestAttempt = useMemo(() => {
    return completedAttempts.length > 0 ? completedAttempts[0] : null;
  }, [completedAttempts]);

  // Mode 2 evaluation (Overall cumulative stats tracker)
  const overallPerformance = useMemo(() => {
    if (completedAttempts.length === 0) return null;
    const totalScoreSum = completedAttempts.reduce((acc, a) => acc + a.score, 0);
    const avgScore = Math.round((totalScoreSum / completedAttempts.length) * 10) / 10;
    const maxAttemptScore = Math.max(...completedAttempts.map(a => a.score));
    const minAttemptScore = Math.min(...completedAttempts.map(a => a.score));

    return {
      count: completedAttempts.length,
      averageScore: avgScore,
      maxScore: maxAttemptScore,
      minScore: minAttemptScore,
    };
  }, [completedAttempts]);

  // MATHONGO + ALLEN STYLE PERCENTILE PREDICTOR MAPPER (Calibrated for June 2026 competition)
  // Dynamic calculation incorporating shift difficulty
  const getPercentileFromScore = (score: number, shift: "TOUGH" | "MODERATE" | "EASY"): number => {
    const s = Math.max(0, Math.min(300, score));
    
    // Shift calibration multipliers:
    // EASY needs ~1.15x higher score for same percentile. TOUGH needs only ~0.85x score.
    let calibratedScore = s;
    if (shift === "TOUGH") {
      calibratedScore = s * 1.18; // Tough shift maps raw 170 -> 200 marks equivalent
    } else if (shift === "EASY") {
      calibratedScore = s * 0.86; // Easy shift maps raw 232 -> 200 marks equivalent
    }

    if (calibratedScore >= 285) return 99.98;
    if (calibratedScore >= 270) return 99.95;
    if (calibratedScore >= 255) return 99.90;
    if (calibratedScore >= 240) return 99.81;
    if (calibratedScore >= 225) return 99.68;
    if (calibratedScore >= 210) return 99.52;
    if (calibratedScore >= 195) return 99.28;
    if (calibratedScore >= 180) return 99.02;
    if (calibratedScore >= 165) return 98.45;
    if (calibratedScore >= 150) return 97.80;
    if (calibratedScore >= 135) return 96.95;
    if (calibratedScore >= 120) return 95.80;
    if (calibratedScore >= 105) return 93.90;
    if (calibratedScore >= 90)  return 90.80;
    if (calibratedScore >= 75)  return 85.50;
    if (calibratedScore >= 60)  return 78.20;
    if (calibratedScore >= 45)  return 68.40;
    if (calibratedScore >= 30)  return 52.10;
    return Math.max(0, Math.round((calibratedScore * 1.7 * 10)) / 10);
  };

  // Inverse Lookup: Score needed for a target percentile given shift difficulty
  const getScoreFromPercentile = (percentile: number, shift: "TOUGH" | "MODERATE" | "EASY"): number => {
    const p = Math.max(0, Math.min(100, percentile));
    let baseScore = 0;

    if (p >= 99.98) baseScore = 285;
    else if (p >= 99.95) baseScore = 270;
    else if (p >= 99.90) baseScore = 255;
    else if (p >= 99.81) baseScore = 240;
    else if (p >= 99.68) baseScore = 225;
    else if (p >= 99.52) baseScore = 210;
    else if (p >= 99.28) baseScore = 195;
    else if (p >= 99.02) baseScore = 180;
    else if (p >= 98.45) baseScore = 165;
    else if (p >= 97.80) baseScore = 150;
    else if (p >= 96.95) baseScore = 135;
    else if (p >= 95.80) baseScore = 120;
    else if (p >= 93.90) baseScore = 105;
    else if (p >= 90.80) baseScore = 90;
    else if (p >= 85.50) baseScore = 75;
    else if (p >= 78.20) baseScore = 60;
    else if (p >= 68.40) baseScore = 45;
    else if (p >= 52.10) baseScore = 30;
    else baseScore = p / 1.7;

    // Shift calibration inverse logic:
    if (shift === "TOUGH") {
      return Math.round(baseScore / 1.18);
    } else if (shift === "EASY") {
      return Math.round(baseScore / 0.86);
    }
    return Math.round(baseScore);
  };

  // Standard Candidate Pool for June 2026: 1,450,000 JEE Aspirants
  const totalJEEAspirants = 1450000;

  // Compute standard Rank based on percentile
  const getRankFromPercentile = (percentile: number): number => {
    const p = Math.max(0.0001, Math.min(100, percentile));
    return Math.max(1, Math.round(((100 - p) / 100) * totalJEEAspirants));
  };

  // Inverse: Percentile from rank
  const getPercentileFromRank = (rank: number): number => {
    const r = Math.max(1, Math.min(totalJEEAspirants, rank));
    return Math.min(99.999, Math.round((1 - r / totalJEEAspirants) * 100 * 100000) / 100000);
  };

  // ACTIVE STATS CALCULATOR
  const activeStats = useMemo(() => {
    let score = 0;
    let percentile = 0;
    let rank = 0;
    let category: "General" | "OBC_NCL" | "SC" | "ST" = "General";
    let titleContext = "";
    let subtextContext = "";

    if (activeMode === "LATEST_SOLVE") {
      score = latestAttempt ? latestAttempt.score : 0;
      percentile = getPercentileFromScore(score, difficultyMode);
      rank = getRankFromPercentile(percentile);
      category = customCategory; 
      titleContext = latestAttempt ? `Latest Mock Test: "${latestAttempt.testName}"` : "None";
      subtextContext = `Calculated using raw score (${score} Pts) adjusted for ${difficultyMode} Shift difficulty parameters.`;
    } 
    else if (activeMode === "OVERALL_STATS") {
      score = overallPerformance ? overallPerformance.averageScore : 0;
      percentile = getPercentileFromScore(score, difficultyMode);
      rank = getRankFromPercentile(percentile);
      category = customCategory;
      titleContext = `Cumulative History: Averages of ${overallPerformance?.count || 0} Saved Mocks`;
      subtextContext = `Uses historical weighted averages across all of your parsed reports under a ${difficultyMode} shift model.`;
    } 
    else {
      // Manual input Mode
      category = customCategory;
      titleContext = "Independent Sandbox Mode";
      subtextContext = `Real-time calibration tool. Adjust parameter inputs below to simulate June 2026 outcomes.`;
      
      if (customInputType === "SCORE") {
        score = customScoreValue;
        percentile = getPercentileFromScore(score, difficultyMode);
        rank = getRankFromPercentile(percentile);
      } else if (customInputType === "PERCENTILE") {
        percentile = customPercentileValue;
        score = getScoreFromPercentile(percentile, difficultyMode);
        rank = getRankFromPercentile(percentile);
      } else {
        rank = customRankValue;
        percentile = getPercentileFromRank(rank);
        score = getScoreFromPercentile(percentile, difficultyMode);
      }
    }

    return { score, percentile, rank, category, titleContext, subtextContext };
  }, [activeMode, latestAttempt, overallPerformance, customInputType, customScoreValue, customPercentileValue, customRankValue, customCategory, difficultyMode]);

  // COLLEGE PREDICTOR EVALUATION ENGINE
  const predictedColleges = useMemo(() => {
    const { rank, category } = activeStats;
    
    return COLLEGES.map(college => {
      const cutoffMapKey = category === "OBC_NCL" ? "OBC_NCL" : category === "SC" ? "SC" : category === "ST" ? "ST" : "General";
      const thresholdRank = college.cutoffs[cutoffMapKey];
      
      let chance: "HIGH" | "MEDIUM" | "DREAM" = "DREAM";
      let matchPercent = 0;

      // Evaluation ranges:
      if (rank <= thresholdRank * 0.75) {
        chance = "HIGH";
        matchPercent = Math.min(100, Math.round(100 - (rank / thresholdRank) * 20));
      } else if (rank <= thresholdRank) {
        chance = "MEDIUM";
        // Linear scale
        matchPercent = Math.round(70 + ((thresholdRank - rank) / (thresholdRank * 0.25)) * 25);
      } else {
        chance = "DREAM";
        matchPercent = Math.max(5, Math.round(100 - (rank / thresholdRank) * 55));
      }

      return {
        ...college,
        thresholdRank,
        chance,
        matchPercent,
      };
    }).filter(c => {
      // Filters
      const matchSearch = c.name.toLowerCase().includes(searchCollegeQuery.toLowerCase()) || 
                          c.location.toLowerCase().includes(searchCollegeQuery.toLowerCase()) ||
                          c.branch.toLowerCase().includes(searchCollegeQuery.toLowerCase());
      const matchTier = tierFilter === "All" || c.tier === tierFilter;
      const matchType = typeFilter === "All" || c.type === typeFilter;
      return matchSearch && matchTier && matchType;
    }).sort((a, b) => b.matchPercent - a.matchPercent);

  }, [activeStats, searchCollegeQuery, tierFilter, typeFilter]);

  // SVG Curve Coordinate plotting parameters
  // X range: 0 -> 300, Y range: 0 -> 100
  const splinePoints = useMemo(() => {
    const points: { score: number; percentile: number }[] = [];
    for (let s = 10; s <= 300; s += 15) {
      points.push({
        score: s,
        percentile: getPercentileFromScore(s, difficultyMode)
      });
    }
    return points;
  }, [difficultyMode]);

  // Map coordinates to SVG viewbox: 400 width, 160 height
  const getSvgCoordinates = (score: number, percentile: number) => {
    const x = (score / 300) * 360 + 20; // margins
    const y = 140 - (percentile / 100) * 120; // invert Y so 100 is at top
    return { x, y };
  };

  const svgPathStr = useMemo(() => {
    return splinePoints.map((p, idx) => {
      const { x, y } = getSvgCoordinates(p.score, p.percentile);
      return `${idx === 0 ? "M" : "L"}${x} ${y}`;
    }).join(" ");
  }, [splinePoints]);

  const handleGraphMouseMove = (e: React.MouseEvent<SVGSVGElement, MouseEvent>) => {
    if (!graphContainerRef.current) return;
    const rect = graphContainerRef.current.getBoundingClientRect();
    const clientX = e.clientX - rect.left;
    
    // Reverse scale clientX back to score index (0-300)
    const targetScore = Math.round(((clientX - 20) / 360) * 300);
    const scoreClamped = Math.max(0, Math.min(300, targetScore));
    const targetPercentile = getPercentileFromScore(scoreClamped, difficultyMode);
    
    setHoveredPoint({
      score: scoreClamped,
      percentile: targetPercentile
    });
  };

  const handleGraphMouseLeave = () => {
    setHoveredPoint(null);
  };

  // Milestone points target analysis values
  const nextTargetInfo = useMemo(() => {
    const currentScore = activeStats.score;
    if (currentScore >= 250) {
      return {
        nextLabel: "Top Elite National Rank (99.9%ile+)",
        scoreGap: Math.max(0, 270 - currentScore),
        benefit: "Compete for computer science seats in top 3 NITs (Trichy, Surathkal, Warangal)."
      };
    } else if (currentScore >= 180) {
      return {
        nextLabel: "Outstanding 99.5+ Percentile Seat",
        scoreGap: 215 - currentScore,
        benefit: "Gain admission to premium Computer Science streams inside high-tier IIITs & core branches in NIT Trichy."
      };
    } else if (currentScore >= 140) {
      return {
        nextLabel: "General Category 99.0+ Percentile Threshold",
        scoreGap: 180 - currentScore,
        benefit: "Unlock assured admission in Computer Engg at DTU Delhi or Netaji Subhas Univ (NSUT)."
      };
    } else {
      return {
        nextLabel: "Stable NIT Admission Range (97.0%ile+)",
        scoreGap: 140 - currentScore,
        benefit: "Cross the 97%ile barrier to guarantee admission in core branches at several state-level NITs."
      };
    }
  }, [activeStats.score]);

  return (
    <div className="max-w-6xl w-full mx-auto px-4 py-6 select-none bg-slate-50">
      
      {/* HEADER HERO ELEMENT */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 md:p-8 border border-slate-800 shadow-xl overflow-hidden relative mb-6">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl -mr-32 -mt-32 pointer-events-none animate-pulse" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-blue-500/5 rounded-full blur-2xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/15 border border-indigo-500/30 text-indigo-300 text-[10px] font-extrabold uppercase tracking-widest rounded-full mb-3 shadow-md">
              <Cpu size={12} className="text-indigo-400 rotate-12" />
              <span>MathonGo & Allen Scaled Engine • June 2026</span>
            </div>
            <h2 className="text-2xl font-black md:text-3xl tracking-tight leading-tight">
              JEE Mains Predictor & Calibration Hub
            </h2>
            <p className="text-xs text-slate-400 mt-2 max-w-2xl font-medium leading-relaxed">
              An institutional-grade forecasting model designed to simulate simulated percentile, CRL ranks, and check opening/closing JoSAA cutoffs for {COLLEGES.length} top-tier engineering institutions. Supported by standard Shift Difficulty adjustments and 3-way calibration indices.
            </p>
          </div>

          <div className="flex gap-4 self-start md:self-center shrink-0">
            <div className="bg-slate-800 border border-slate-700/60 p-4 rounded-xl text-center min-w-[90px] shadow-lg">
              <div className="text-2xl font-black text-indigo-400 font-mono">{completedAttempts.length}</div>
              <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mt-0.5">Attempted</div>
            </div>
            <div className="bg-slate-800 border border-slate-700/60 p-4 rounded-xl text-center min-w-[90px] shadow-lg">
              <div className="text-2xl font-black text-emerald-400 font-mono">{savedPapersCount}</div>
              <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mt-0.5">Mock Library</div>
            </div>
          </div>
        </div>

        {/* SECURITY & DEVICE RETENTION BANNER */}
        <div className="mt-6 bg-slate-850 border border-slate-800 p-4 rounded-xl flex items-center justify-between gap-4 flex-col sm:flex-row relative z-10 text-left">
          <div className="flex items-start gap-3">
            <ShieldAlert size={20} className="text-indigo-400 shrink-0 mt-0.5" />
            <div className="text-left">
              <h4 className="text-xs font-black text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                <span>Personal Computer Storage Guidance</span>
                <span className="text-[8px] bg-indigo-500/20 text-indigo-300 px-1.5 py-0.5 rounded-full font-bold">Highly Suggested</span>
              </h4>
              <p className="text-[11px] text-slate-400 font-semibold leading-relaxed mt-1">
                If practicing on your <strong>personal computer</strong>, please <strong className="text-indigo-200 font-bold">do not clear the browser storage caching keys</strong>. This portal features native offline metric models that compile your historic weak chapters, mock attempts, incorrect patterns, and cumulative all-India calibration trends to give you accurate predictive suggestions.
              </p>
            </div>
          </div>
          <span className="text-[10px] bg-slate-800 text-indigo-300 font-bold px-3 py-1.5 rounded-lg shrink-0 border border-slate-700/60 font-mono">
            🔒 Local Storage Encryption Active
          </span>
        </div>
      </div>

      {/* THREE-WAY PREDICTOR INGESTION MODE SELECTOR */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        
        {/* SIDE CONTROLS & SELECTION CRITERIA */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          
          {/* ANALYTICAL MODE TAB SELECTION */}
          <div className="bg-white rounded-2xl border border-slate-200 hover:border-slate-300 shadow-sm p-5 text-left transition-all">
            <h3 className="text-xs font-black text-slate-800 uppercase tracking-wider mb-4 flex items-center gap-2 pb-2 border-b border-slate-100">
              <Sliders size={15} className="text-[#1a3a5f]" />
              <span>Dimensions of Calibration</span>
            </h3>

            <div className="space-y-2.5">
              
              {/* Mode 1: Latest solved mock test */}
              <button
                type="button"
                onClick={() => {
                  if (completedAttempts.length > 0) setActiveMode("LATEST_SOLVE");
                }}
                disabled={completedAttempts.length === 0}
                className={`w-full p-3 rounded-xl border text-left transition relative overflow-hidden flex flex-col justify-start group cursor-pointer ${
                  activeMode === "LATEST_SOLVE" 
                    ? "border-indigo-600 bg-indigo-50/20" 
                    : "border-slate-150 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <span className={`text-[11px] font-extrabold tracking-wider uppercase ${activeMode === "LATEST_SOLVE" ? "text-indigo-700" : "text-slate-700"}`}>
                    1. Last Live Mock Solving
                  </span>
                  {activeMode === "LATEST_SOLVE" && <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 animate-ping" />}
                </div>
                <span className="text-[10px] text-slate-400 font-semibold mt-1 leading-normal">
                  Predict based on your single, most recent finished exam scorecard parameters.
                </span>
                {completedAttempts.length === 0 && (
                  <span className="text-[9px] text-[#e11d48] font-bold uppercase mt-1">No completed mocks found</span>
                )}
              </button>

              {/* Mode 2: Cumulative Averages */}
              <button
                type="button"
                onClick={() => {
                  if (completedAttempts.length > 0) setActiveMode("OVERALL_STATS");
                }}
                disabled={completedAttempts.length === 0}
                className={`w-full p-3 rounded-xl border text-left transition relative overflow-hidden flex flex-col justify-start group cursor-pointer ${
                  activeMode === "OVERALL_STATS" 
                    ? "border-blue-600 bg-blue-50/20" 
                    : "border-slate-150 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <span className={`text-[11px] font-extrabold tracking-wider uppercase ${activeMode === "OVERALL_STATS" ? "text-blue-700" : "text-slate-700"}`}>
                    2. All-Time Cumulative Stats
                  </span>
                  {activeMode === "OVERALL_STATS" && <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />}
                </div>
                <span className="text-[10px] text-slate-400 font-semibold mt-1 leading-normal">
                  Weighted simulation averaged from every single test score entry in your local database.
                </span>
              </button>

              {/* Mode 3: Sandbox Sandbox Model */}
              <button
                type="button"
                onClick={() => setActiveMode("CUSTOM_MANUAL")}
                className={`w-full p-3 rounded-xl border text-left transition relative overflow-hidden flex flex-col justify-start group cursor-pointer ${
                  activeMode === "CUSTOM_MANUAL" 
                    ? "border-emerald-600 bg-emerald-50/20" 
                    : "border-slate-150 hover:bg-slate-50"
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <span className={`text-[11px] font-extrabold tracking-wider uppercase ${activeMode === "CUSTOM_MANUAL" ? "text-emerald-700" : "text-slate-700"}`}>
                    3. Independent Sandbox Mode
                  </span>
                  {activeMode === "CUSTOM_MANUAL" && <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" />}
                </div>
                <span className="text-[10px] text-slate-400 font-semibold mt-1 leading-normal">
                  Freely toggle score, rank, or percentile inputs directly to view mock admissions options.
                </span>
              </button>

            </div>
          </div>

          {/* PARAMETER CONTROLS */}
          <div className="bg-white rounded-2xl border border-slate-200 hover:border-slate-300 shadow-sm p-5 text-left flex-1 flex flex-col justify-between">
            <div className="space-y-5">
              <h3 className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-2 pb-2 border-b border-slate-100">
                <Compass size={15} className="text-indigo-650" />
                <span>Simulation Parameters</span>
              </h3>

              {/* DIFFICULTY METRIC MODIFIER (MATHONGO SHIFT MECHANIC) */}
              <div className="space-y-1.5 p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                <label className="block text-[10.5px] font-extrabold text-[#1a3a5f] uppercase tracking-wide flex items-center gap-1.5">
                  <Clock size={12} className="text-blue-500 animate-spin-slow" />
                  <span>Choose Shift Difficulty Scale:</span>
                </label>
                <p className="text-[9.5px] text-slate-450 font-semibold leading-snug">
                  Shift severity plays a heavy role in final normalized percentiles. Simulating shift difficulty sets custom cutoffs:
                </p>
                <div className="grid grid-cols-3 gap-1.5 mt-2">
                  {[
                    { id: "TOUGH", label: "🔴 Tough", desc: "Lower marks needed" },
                    { id: "MODERATE", label: "🟡 Medium", desc: "Balanced standard" },
                    { id: "EASY", label: "🟢 Easy", desc: "High competition" }
                  ].map(sh => (
                    <button
                      key={sh.id}
                      type="button"
                      onClick={() => setDifficultyMode(sh.id as any)}
                      className={`py-1.5 px-1 rounded-lg border text-[11px] font-black text-center transition flex flex-col justify-center items-center ${
                        difficultyMode === sh.id 
                          ? "bg-[#1a3a5f] text-white border-[#1a3a5f] shadow-sm shadow-[#1a3a5f]/20" 
                          : "border-slate-200 bg-white hover:bg-slate-50 text-slate-600"
                      }`}
                    >
                      <span>{sh.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* JOSAA RESERVATION CATEGORY PICKER */}
              <div className="space-y-1.5">
                <label className="block text-[10.5px] font-extrabold text-slate-700 uppercase tracking-wide">
                  JoSAA Quota Reservation Category:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: "General", label: "Open (CRL Rank)" },
                    { id: "OBC_NCL", label: "OBC-NCL (OBC Rank)" },
                    { id: "SC", label: "SC Quota" },
                    { id: "ST", label: "ST Quota" }
                  ].map(cat => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setCustomCategory(cat.id as any)}
                      className={`py-1.5 px-2 rounded-lg border text-[11px] font-bold text-center transition ${
                        customCategory === cat.id 
                          ? "bg-[#1a3a5f] text-white border-[#1a3a5f] font-extrabold" 
                          : "border-slate-200 hover:bg-slate-50 text-slate-650"
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* DYNAMIC COMPONENT INPUTS BY ACTIVE INGESTION MODE */}
              {activeMode === "LATEST_SOLVE" && latestAttempt && (
                <div className="bg-indigo-50/40 rounded-xl p-3 border border-indigo-150 space-y-2">
                  <div className="text-[10px] font-black text-indigo-700 uppercase tracking-widest flex items-center gap-1">
                    <Target size={10} />
                    <span>Active Input scorecard</span>
                  </div>
                  <div className="text-xs font-black text-slate-800 truncate">{latestAttempt.testName}</div>
                  <div className="flex items-baseline gap-1 font-mono">
                    <span className="text-2xl font-black text-slate-850">{latestAttempt.score}</span>
                    <span className="text-xs text-slate-500 font-bold">/ {latestAttempt.maxScore} Pts</span>
                  </div>
                  <p className="text-[10px] text-slate-450 italic font-semibold leading-snug">
                    Score fetched directly from standard storage map. Re-do this exam or click 'Review' to inspect mistakes.
                  </p>
                </div>
              )}

              {activeMode === "OVERALL_STATS" && overallPerformance && (
                <div className="bg-blue-50/40 rounded-xl p-3.5 border border-blue-150 space-y-2">
                  <div className="text-[10px] font-black text-blue-700 uppercase tracking-widest">Averaged historic stats</div>
                  <div className="flex justify-between text-xs font-bold text-slate-600 font-mono">
                    <span>Mocks parsed:</span>
                    <span className="text-slate-800">{overallPerformance.count} Tests</span>
                  </div>
                  <div className="flex justify-between text-xs font-bold text-slate-600 font-mono">
                    <span>Average score:</span>
                    <span className="text-[#1a3a5f]">{overallPerformance.averageScore} /300</span>
                  </div>
                  <div className="flex justify-between text-xs font-bold text-slate-600 font-mono">
                    <span>Peak performance:</span>
                    <span className="text-emerald-700">+{overallPerformance.maxScore} Marks</span>
                  </div>
                </div>
              )}

              {activeMode === "CUSTOM_MANUAL" && (
                <div className="space-y-4 pt-1">
                  <div className="space-y-1">
                    <label className="block text-[10.5px] font-extrabold text-slate-700 uppercase tracking-wider">
                      Specify Custom Dimension Input:
                    </label>
                    <div className="flex rounded-lg shadow-2xs border border-slate-200">
                      {[
                        { id: "SCORE", label: "Mains Score" },
                        { id: "PERCENTILE", label: "Percentile" },
                        { id: "RANK", label: "CRL Rank" }
                      ].map(type => (
                        <button
                          key={type.id}
                          type="button"
                          onClick={() => setCustomInputType(type.id as any)}
                          className={`flex-1 py-1.5 text-[10px] font-bold text-center transition cursor-pointer ${
                            customInputType === type.id 
                              ? "bg-emerald-500 text-white font-extrabold" 
                              : "bg-white hover:bg-slate-50 text-slate-600"
                          }`}
                        >
                          {type.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* CUSTOM DITHER FORMS */}
                  {customInputType === "SCORE" && (
                    <div className="space-y-2">
                      <div className="flex justify-between items-center bg-emerald-50/40 p-2.5 rounded-lg border border-emerald-100 font-mono">
                        <span className="text-[10px] font-bold text-emerald-800">Target Score:</span>
                        <input
                          type="number"
                          min="0"
                          max="300"
                          value={customScoreValue}
                          onChange={(e) => setCustomScoreValue(Math.max(0, Math.min(300, Number(e.target.value) || 0)))}
                          className="w-16 text-center font-bold text-slate-800 bg-white border border-slate-200 rounded text-xs py-0.5"
                        />
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="300"
                        value={customScoreValue}
                        onChange={(e) => setCustomScoreValue(Number(e.target.value))}
                        className="w-full accent-emerald-500 cursor-pointer"
                      />
                      <div className="flex justify-between text-[9px] text-slate-400 font-black uppercase tracking-wider font-mono">
                        <span>0 Marks</span>
                        <span>150 Marks</span>
                        <span>300 Marks</span>
                      </div>
                    </div>
                  )}

                  {customInputType === "PERCENTILE" && (
                    <div className="space-y-2">
                      <div className="flex justify-between items-center bg-emerald-50/40 p-2.5 rounded-lg border border-emerald-100 font-mono">
                        <span className="text-[10px] font-bold text-emerald-800">Target Percentile:</span>
                        <input
                          type="number"
                          step="0.1"
                          min="0"
                          max="100"
                          value={customPercentileValue}
                          onChange={(e) => setCustomPercentileValue(Math.max(0, Math.min(100, Number(e.target.value) || 0)))}
                          className="w-16 text-center font-bold text-slate-800 bg-white border border-slate-200 rounded text-xs py-0.5"
                        />
                      </div>
                      <input
                        type="range"
                        min="60"
                        max="100"
                        step="0.1"
                        value={customPercentileValue}
                        onChange={(e) => setCustomPercentileValue(Number(e.target.value))}
                        className="w-full accent-emerald-500 cursor-pointer"
                      />
                      <div className="flex justify-between text-[9px] text-slate-400 font-black uppercase tracking-wider font-mono">
                        <span>60 %ile</span>
                        <span>80 %ile</span>
                        <span>100 %ile</span>
                      </div>
                    </div>
                  )}

                  {customInputType === "RANK" && (
                    <div className="space-y-2">
                      <div className="flex justify-between items-center bg-emerald-50/40 p-2.5 rounded-lg border border-emerald-100 font-mono">
                        <span className="text-[10px] font-bold text-emerald-800">CRL Merit Rank:</span>
                        <input
                          type="number"
                          min="1"
                          max={totalJEEAspirants}
                          value={customRankValue}
                          onChange={(e) => setCustomRankValue(Math.max(1, Math.min(totalJEEAspirants, Number(e.target.value) || 1)))}
                          className="w-24 text-center font-bold text-slate-800 bg-white border border-slate-200 rounded text-xs py-0.5"
                        />
                      </div>
                      <input
                        type="range"
                        min="1"
                        max="200000"
                        step="100"
                        value={customRankValue > 200000 ? 200000 : customRankValue}
                        onChange={(e) => setCustomRankValue(Number(e.target.value))}
                        className="w-full accent-emerald-500 cursor-pointer"
                      />
                      <div className="flex justify-between text-[9px] text-slate-400 font-black uppercase tracking-wider font-mono">
                        <span>Rank 1</span>
                        <span>Rank 100,000</span>
                        <span>Rank 200,000+</span>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            <p className="mt-6 text-[9px] text-slate-400 leading-normal bg-slate-50 p-2.5 border border-slate-100 rounded-lg">
              * Ranks are predicted based on a conservative state distribution mapping normalized over the cumulative {totalJEEAspirants.toLocaleString("en-IN")} candidate pool.
            </p>
          </div>

        </div>

        {/* OUTPUT ANALYSIS & ADMISSIBILITY LISTING */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          
          {/* MATHONGO-STYLE HIGH-FIDELITY GRADUATION PLOT & METRIC CARD */}
          <div className="bg-white rounded-2xl border border-slate-200 hover:border-slate-300 shadow-sm p-6 text-left relative overflow-hidden transition-all">
            <div className={`absolute top-0 left-0 right-0 h-1.5 bg-[#1a3a5f]`} />

            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-100 pb-4 mb-5">
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest px-2.5 py-1 rounded-md bg-indigo-50 text-[#1a3a5f] border border-indigo-100">
                  {difficultyMode} COMPETITION CURVE CALIBRATION
                </span>
                <p className="text-[11px] text-slate-450 font-bold mt-1.5 italic">{activeStats.subtextContext}</p>
              </div>

              <div className="flex items-center gap-2 text-[11px] font-bold text-slate-500">
                <Calendar size={13} className="text-slate-400" />
                <span>Simulation Target Date: <strong className="text-slate-800">June 2026</strong></span>
              </div>
            </div>

            {/* HIGH CONTRAST DOUBLE DECK STATUS METRICS */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
              
              <div className="bg-slate-50/80 p-4 border border-slate-150 rounded-xl space-y-1 relative group">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1">
                  <span>🎯</span> Normalized Score
                </span>
                <div className="flex items-baseline gap-1 font-mono">
                  <span className="text-3xl font-black text-slate-800 leading-none">{Math.round(activeStats.score)}</span>
                  <span className="text-xs text-slate-500 font-bold">/300 Pts</span>
                </div>
                <div className="w-full bg-slate-200 h-1 rounded-full overflow-hidden mt-2">
                  <div className="bg-[#1a3a5f] h-full rounded-full transition-all duration-300" style={{ width: `${Math.min(100, (activeStats.score / 300) * 100)}%` }} />
                </div>
              </div>

              <div className="bg-slate-50/80 p-4 border border-slate-150 rounded-xl space-y-1 relative group">
                <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest flex items-center gap-1.5">
                  <BarChart2 size={13} className="text-blue-500" />
                  <span>Percentile Profile</span>
                </span>
                <div className="flex items-baseline gap-1 font-mono">
                  <span className="text-3xl font-black text-blue-800 leading-none">{activeStats.percentile.toFixed(2)}</span>
                  <span className="text-xs text-blue-400 font-bold">%ile</span>
                </div>
                <div className="w-full bg-blue-100 h-1 rounded-full overflow-hidden mt-2">
                  <div className="bg-blue-600 h-full rounded-full transition-all duration-300" style={{ width: `${activeStats.percentile}%` }} />
                </div>
              </div>

              <div className="bg-slate-50/80 p-4 border border-slate-150 rounded-xl space-y-1 relative group animate-pulse-slow">
                <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest flex items-center gap-1.5">
                  <Award size={13} className="text-indigo-500" />
                  <span>Pan-India merit CRL</span>
                </span>
                <div className="flex items-baseline gap-1 font-mono">
                  <span className="text-3xl font-black text-indigo-900 leading-none">
                    ~{activeStats.rank.toLocaleString("en-IN")}
                  </span>
                  <span className="text-xs text-indigo-400 font-bold">Rank</span>
                </div>
                <p className="text-[9px] text-slate-400 font-semibold mt-1">
                  Based on target normalized shift weights.
                </p>
              </div>

            </div>

            {/* DYNAMIC INTERACTIVE SPLINE PLOT CHART (SVG CLASSWORK INTERACTION) */}
            <div className="p-4 bg-slate-900 text-white rounded-xl border border-slate-800 mb-6 relative">
              
              <div className="flex justify-between items-center mb-3">
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 animate-pulse" />
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-300">
                    Interactive Percentile Curve Map
                  </span>
                </div>
                <span className="text-[9px] text-slate-500 font-mono">
                  Hover anywhere on the curve to test mock score predictions
                </span>
              </div>

              {/* DRAW SVG SPACE */}
              <div className="relative h-40 w-full">
                <svg 
                  ref={graphContainerRef}
                  viewBox="0 0 400 160" 
                  className="w-full h-full cursor-crosshair overflow-visible"
                  onMouseMove={handleGraphMouseMove}
                  onMouseLeave={handleGraphMouseLeave}
                >
                  {/* Grid Lines */}
                  <line x1="20" y1="20" x2="380" y2="20" stroke="#1e293b" strokeDasharray="3 3" />
                  <line x1="20" y1="80" x2="380" y2="80" stroke="#1e293b" strokeDasharray="3 3" />
                  <line x1="20" y1="140" x2="380" y2="140" stroke="#334155" strokeWidth="1.5" />
                  
                  {/* Score intervals */}
                  <text x="20" y="152" fill="#475569" fontSize="8" textAnchor="middle" fontWeight="bold">0</text>
                  <text x="110" y="152" fill="#475569" fontSize="8" textAnchor="middle" fontWeight="bold">75 Marks</text>
                  <text x="200" y="152" fill="#475569" fontSize="8" textAnchor="middle" fontWeight="bold">150</text>
                  <text x="290" y="152" fill="#475569" fontSize="8" textAnchor="middle" fontWeight="bold">225</text>
                  <text x="380" y="152" fill="#475569" fontSize="8" textAnchor="middle" fontWeight="bold font-mono">300 M</text>

                  {/* Y Axis descriptors */}
                  <text x="14" y="23" fill="#475569" fontSize="8" textAnchor="end" fontWeight="bold">100%</text>
                  <text x="14" y="83" fill="#475569" fontSize="8" textAnchor="end" fontWeight="bold">50%</text>
                  <text x="14" y="143" fill="#475569" fontSize="8" textAnchor="end" fontWeight="bold">0%</text>

                  {/* Fill ambient area under spline */}
                  <path 
                    d={`M 20 140 ${svgPathStr.slice(1)} L 380 140 Z`} 
                    fill="url(#grad)" 
                    className="opacity-15 transition-all duration-300"
                  />

                  {/* Spline Path */}
                  <path 
                    d={svgPathStr} 
                    fill="none" 
                    stroke="url(#splineGrad)" 
                    strokeWidth="3" 
                    strokeLinecap="round"
                    className="transition-all duration-300"
                  />

                  {/* CURRENT USER POSITION */}
                  {(() => {
                    const coord = getSvgCoordinates(activeStats.score, activeStats.percentile);
                    return (
                      <g className="transition-all duration-300">
                        <line x1={coord.x} y1="140" x2={coord.x} y2={coord.y} stroke="#6366f1" strokeDasharray="2 2" strokeWidth="1" />
                        <line x1="20" y1={coord.y} x2={coord.x} y2={coord.y} stroke="#6366f1" strokeDasharray="2 2" strokeWidth="1" />
                        <circle cx={coord.x} cy={coord.y} r="6" fill="#4f46e5" stroke="#ffffff" strokeWidth="2" className="animate-pulse" />
                        <circle cx={coord.x} cy={coord.y} r="12" fill="#4f46e5" className="opacity-20 animate-ping" />
                      </g>
                    );
                  })()}

                  {/* HOVER COORDINATE PLOT */}
                  {hoveredPoint && (
                    <g>
                      {(() => {
                        const coord = getSvgCoordinates(hoveredPoint.score, hoveredPoint.percentile);
                        return (
                          <>
                            <line x1={coord.x} y1="140" x2={coord.x} y2={coord.y} stroke="#10b981" strokeWidth="1.5" />
                            <circle cx={coord.x} cy={coord.y} r="5" fill="#10b981" stroke="#ffffff" strokeWidth="1.5" />
                          </>
                        );
                      })()}
                    </g>
                  )}

                  {/* Gradients */}
                  <defs>
                    <linearGradient id="grad" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#4f46e5" />
                      <stop offset="100%" stopColor="#0f172a" />
                    </linearGradient>
                    <linearGradient id="splineGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#818cf8" />
                      <stop offset="50%" stopColor="#4f46e5" />
                      <stop offset="100%" stopColor="#10b981" />
                    </linearGradient>
                  </defs>
                </svg>
              </div>

              {/* DYNAMIC COORDINATES DRIFT INSIDE GRAPH COMPONENT */}
              <div className="absolute top-2.5 right-4 pointer-events-none min-w-[130px]">
                {hoveredPoint ? (
                  <div className="bg-slate-950/80 backdrop-blur-xs p-2 rounded-lg border border-slate-700 text-left text-[10px] space-y-1 font-mono">
                    <span className="text-[#10b981] font-extrabold uppercase block text-[8px] tracking-widest">🚨 Interactive Probe</span>
                    <div>Marks: <strong className="text-white font-black">{hoveredPoint.score} Pts</strong></div>
                    <div>Percentile: <strong className="text-white font-black">{hoveredPoint.percentile.toFixed(2)}%</strong></div>
                    <div>Est Rank: <strong className="text-slate-300">~{getRankFromPercentile(hoveredPoint.percentile).toLocaleString("en-IN")}</strong></div>
                  </div>
                ) : (
                  <div className="bg-[#1e1b4b]/70 p-2 rounded-lg border border-indigo-950 text-left text-[10px] space-y-1 font-mono">
                    <span className="text-indigo-400 font-extrabold uppercase block text-[8px] tracking-widest">📈 Active Plot point</span>
                    <div>Marks: <strong className="text-white font-black">{Math.round(activeStats.score)}</strong></div>
                    <div>Percentile: <strong className="text-white font-black">{activeStats.percentile.toFixed(2)}%</strong></div>
                    <div>Est Rank: <strong className="text-indigo-300">~{activeStats.rank.toLocaleString("en-IN")}</strong></div>
                  </div>
                )}
              </div>
            </div>

            {/* MILESTONE CHECKLIST GAUGER */}
            <div className="bg-indigo-50/40 border border-indigo-100 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
              <div className="flex items-start gap-3">
                <TrendingUp size={20} className="text-indigo-600 mt-0.5 shrink-0" />
                <div>
                  <h4 className="font-extrabold text-slate-800">
                    Next Target Runway: <span className="text-indigo-700">{nextTargetInfo.nextLabel}</span>
                  </h4>
                  <p className="text-[10px] text-slate-500 mt-0.5 leading-normal font-medium">
                    {nextTargetInfo.benefit}
                  </p>
                </div>
              </div>

              <div className="bg-white px-3 py-2 border border-indigo-150 rounded-lg text-center shrink-0 min-w-[120px] font-mono shadow-2xs">
                <div className="text-[9px] font-extrabold uppercase text-slate-400">Score Target Gap</div>
                <div className="text-base font-black text-indigo-750 mt-0.5">
                  +{nextTargetInfo.scoreGap} Marks
                </div>
                <div className="text-[8px] font-bold text-emerald-600 mt-0.5">
                  (~{Math.ceil(nextTargetInfo.scoreGap / 4)} Correct MCQ checks)
                </div>
              </div>
            </div>

          </div>

          {/* REALISTIC JOSAA ADMISSIONS PREDICTION SHEET */}
          <div className="bg-white rounded-2xl border border-slate-200 hover:border-slate-300 shadow-sm p-6 text-left flex-1 flex flex-col transition-all">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-4 mb-4">
              <div>
                <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-1.5">
                  <Award size={16} className="text-amber-500 animate-bounce" />
                  <span>June 2026 JoSAA Admissibility predictor</span>
                </h3>
                <p className="text-[10.5px] text-slate-450 font-semibold mt-1">
                  Matching computed Rank &lt;<span className="text-indigo-600 font-bold">CRL {activeStats.rank}</span>&gt; as <span className="text-slate-800 font-bold">{customCategory} reservation pool</span>.
                </p>
              </div>

              {/* INLINE FILTERS */}
              <div className="flex flex-col sm:flex-row gap-2">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search NITs/IIITs or branch"
                    value={searchCollegeQuery}
                    onChange={(e) => setSearchCollegeQuery(e.target.value)}
                    className="w-full sm:w-44 pl-7 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-800 placeholder-slate-400 focus:outline-hidden focus:border-indigo-500"
                  />
                  <Search size={11} className="text-slate-400 absolute left-2.5 top-3" />
                </div>

                <div className="flex gap-1.5">
                  <select
                    value={tierFilter}
                    onChange={(e) => setTierFilter(e.target.value as any)}
                    className="bg-slate-50 border border-slate-200 text-[11px] font-bold py-1.5 px-2 rounded-lg text-slate-700 cursor-pointer"
                  >
                    <option value="All">All Tiers</option>
                    <option value="Tier-1">Tier-1 Elite</option>
                    <option value="Tier-2">Tier-2 Normal</option>
                    <option value="Tier-3">Tier-3 Local</option>
                  </select>

                  <select
                    value={typeFilter}
                    onChange={(e) => setTypeFilter(e.target.value as any)}
                    className="bg-slate-50 border border-slate-200 text-[11px] font-bold py-1.5 px-2 rounded-lg text-slate-700 cursor-pointer"
                  >
                    <option value="All">All Types</option>
                    <option value="NIT">NITs Only</option>
                    <option value="IIIT">IIITs Only</option>
                    <option value="GFTI">GFTIs/DTU</option>
                  </select>
                </div>
              </div>
            </div>

            {/* RESPONSE COMPONENT LIST */}
            <div className="space-y-3 flex-1 overflow-y-auto max-h-[420px] pr-1.5">
              {predictedColleges.length > 0 ? (
                predictedColleges.map((college, idx) => {
                  return (
                    <div 
                      key={idx}
                      className="p-4 rounded-xl border border-slate-200 bg-slate-50/40 hover:bg-slate-50/90 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:border-indigo-300 transition duration-150"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <h4 className="font-extrabold text-slate-800 text-xs tracking-tight">{college.name}</h4>
                          <span className={`text-[8px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded ${
                            college.tier === "Tier-1" ? "bg-orange-50 text-orange-700 border border-orange-100" :
                            college.tier === "Tier-2" ? "bg-teal-50 text-teal-700 border border-teal-100" :
                            "bg-blue-50 text-blue-700 border border-blue-100"
                          }`}>
                            {college.tier}
                          </span>
                          <span className={`text-[8px] font-black px-1.5 py-0.5 rounded bg-slate-200/80 text-slate-700 border border-slate-300`}>
                            {college.type}
                          </span>
                        </div>
                        
                        <p className="text-[10px] text-slate-400 mt-1 flex items-center gap-1 font-semibold">
                          <MapPin size={10} className="text-slate-400" />
                          <span>{college.location}</span>
                        </p>
                        
                        <div className="mt-3 bg-white p-2 border border-slate-200 rounded-lg flex justify-between items-center text-[10.5px] font-bold text-slate-700">
                          <span className="truncate mr-2">📂 Stream: {college.branch}</span>
                          <span className="text-slate-500 shrink-0 font-mono text-[9.5px]">
                            JoSAA Round 6 cutoff: <strong className="text-slate-800 font-extrabold">{college.thresholdRank.toLocaleString("en-IN")} CRL</strong>
                          </span>
                        </div>
                      </div>

                      {/* PROBABILITY CHIPS */}
                      <div className="flex flex-row md:flex-col items-center justify-between md:justify-center text-center gap-1 sm:gap-2 border-t md:border-t-0 md:border-l border-slate-200 pt-3 md:pt-0 md:pl-4 shrink-0 min-w-[130px]">
                        <div className="text-left md:text-center">
                          <span className="text-[9px] text-slate-450 block font-bold uppercase tracking-widest">Probability</span>
                          <span className={`text-xs font-black block mt-0.5 ${
                            college.chance === "HIGH" ? "text-emerald-600" :
                            college.chance === "MEDIUM" ? "text-indigo-600" :
                            "text-amber-600/90"
                          }`}>
                            {college.chance === "HIGH" ? "🎖️ High/Safe" :
                             college.chance === "MEDIUM" ? "⚡ Moderate Match" :
                             "✨ Dream Target"}
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <div className="w-16 bg-slate-200 h-2 rounded-full overflow-hidden">
                            <div className={`h-full rounded-full transition-all ${
                              college.chance === "HIGH" ? "bg-emerald-500" :
                              college.chance === "MEDIUM" ? "bg-indigo-500" :
                              "bg-amber-500"
                            }`} style={{ width: `${college.matchPercent}%` }} />
                          </div>
                          <span className="text-[10.5px] font-mono font-black text-slate-700">{college.matchPercent}%</span>
                        </div>
                      </div>

                    </div>
                  );
                })
              ) : (
                <div className="py-16 text-center text-slate-400 flex flex-col items-center justify-center gap-2 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                  <span className="text-4xl">🧩</span>
                  <p className="text-xs font-bold text-slate-700">No Engineering Institutions Match Filters</p>
                  <p className="text-[10.5px] text-slate-450 max-w-sm mt-0.5 leading-normal">
                    Try adjusting the search query bounds, switching category pools, or altering the shift difficulty normalizer to modify the active rank calibration.
                  </p>
                </div>
              )}
            </div>

          </div>

        </div>

      </div>

      {/* STATUTORY AND LEGAL DISCLAIMER PANEL FOR COMPLIANCE */}
      <div className="mt-8 bg-slate-100 border border-slate-200 rounded-xl p-4 text-left select-text">
        <div className="flex gap-2.5 items-start text-[11px] text-slate-500 leading-relaxed font-semibold">
          <span className="text-sm mt-0.5 select-none">⚖️</span>
          <div>
            <strong className="text-slate-800 uppercase tracking-wider text-[10px] font-extrabold block mb-1">
              Statutory Educational & Admissions Disclaimer
            </strong>
            <p className="mb-2">
              This simulation program and its admissions forecasts are educational tools constructed exclusively for candidate practice, JEE Main CBT skill calibration, and learning simulation. This application is <strong>NOT</strong> affiliated with, associated with, sponsored by, or endorsed by the <strong>National Testing Agency (NTA)</strong>, the <strong>Joint Seat Allocation Authority (JoSAA)</strong>, the <strong>Central Seat Allocation Board (CSAB)</strong>, or any Ministry of Education (Govt. of India) institutions.
            </p>
            <p>
              Actual JEE Mains ranks, marks-to-percentile curves, and college cutoff thresholds are formulated strictly under official parameters during statutory examination blocks. All trade names, copyrights, and entity marks (including "JEE Main", "NTA", and "JoSAA") mentioned herein are trademarks or registered trademarks of their respective holders, with whom this practice portal maintains zero authorization or legal connection.
            </p>
          </div>
        </div>
      </div>

    </div>
  );
}
