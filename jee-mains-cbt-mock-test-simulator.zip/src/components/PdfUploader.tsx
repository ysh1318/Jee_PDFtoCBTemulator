/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from "react";
import { 
  Upload, FileText, CheckCircle, Database, HelpCircle, AlertCircle, ArrowRight, BookOpen,
  Key, Eye, EyeOff, Check, Cpu, Settings
} from "lucide-react";
import { Question } from "../types";
import { PRESET_MOCK_TEST } from "../data/presetTest";

const ALICE_DIALOGUE_POOL = {
  cheering: [
    "Go go go, Rin-chan! No equation stands a chance! 📣",
    "Whoooo! Look at those math symbols flying out! You're a parsing superstar! ✨",
    "You got this, Rin! Extract those Chemistry reaction formulas! 💖",
    "Go fight! Standard-grade mock questions key set! 🚀"
  ],
  ramen: [
    "Mmm... this hot spicy Ramen tastes amazing! Want a bite, Rin-chan? 🍜",
    "Slurp slurp... Do Chemistry isomers smell like tasty pork broth? 🍥",
    "Ramen, coffee, and definite integrals are the breakfast of champions! 🍥",
    "Eating hot noodles triggers active brain power! Care for some? 🍜"
  ],
  sleeping: [
    "Zzz... only five more minutes mom... I'm integrating calculus bounds... 😴",
    "Zzz... atomic Bohr orbits make such cozy pillows... cuddle... 💤",
    "Zzz... why do complex pulley symbols keep jumping around in my head... 🥱",
    "Zzz... don't worry, my subconscious is cheering for you... 😴"
  ],
  boba: [
    "Ah! Brown sugar Boba tea! The tapioca pearls look like little atomic spheres! 🧋",
    "Sip, sip... Double sugar gives you double parsing speed! 🧋",
    "Sweet sweet boba milk turns complex Physics coordinate vector math into easy fun! 🧋",
    "Nothing beats cold bubble milk tea when we are auditing equations! ✨"
  ],
  peace: [
    "Peace peace! You've got this, Rin-chan! ✌️",
    "Perfect coordinate grid alignment achieved! Bravo! ✌️",
    "Woohoo! Rin-chan, you are literally the smartest black-haired coder! 🎉",
    "Smile! We're extracting this mock test beautifully! 📸"
  ]
};

const RIN_DIALOGUE_POOL = {
  idle: [
    "Calibrating neural layout coordinates for the mock test...",
    "Waking up NLP scanners to parse JEE syllabus chapters..."
  ],
  Physics: [
    "Writing OCR coordinate vector parameters for Physics MCQs... ⚙️",
    "Normalizing electromagnetic field equations and pulleys... ⚙️",
    "Converting kinematic and thermodynamics formulas into clean display LaTeX... ⚙️",
    "Securing standard MCQ layouts for Physics Section... ⚙️"
  ],
  Chemistry: [
    "Parsing Chemistry organic isomers and nomenclature chains... 🧪",
    "Formulating chemical gas equilibria constants Kc and Kp... 🧪",
    "Balancing chemical redox stoichiometry ratios... 🧪",
    "Converting hybrid orbitals into structured formulas... 🧪"
  ],
  Mathematics: [
    "Extracting Math definite calculus double integrals... 📈",
    "Structuring 3D vector math and direction cosines... 📈",
    "Formatting binomial progression sequence matrices... 📈",
    "Confirming differentiability limits of the mock equations... 📈"
  ]
};

interface PdfUploaderProps {
  onTestLoaded: (testName: string, questions: Question[]) => void;
}

export function PdfUploader({ onTestLoaded }: PdfUploaderProps) {
  const [dragActive, setDragActive] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState("");
  const [fileName, setFileName] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Custom provider-specific API Key States
  const [showApiKeySettings, setShowApiKeySettings] = useState(true);
  const [apiKeys, setApiKeys] = useState<{
    gemini: string;
    openai: string;
    anthropic: string;
    groq: string;
  }>(() => {
    try {
      return {
        gemini: localStorage.getItem("user_gemini_api_key") || "",
        openai: localStorage.getItem("user_openai_api_key") || "",
        anthropic: localStorage.getItem("user_anthropic_api_key") || "",
        groq: localStorage.getItem("user_groq_api_key") || "",
      };
    } catch {
      return { gemini: "", openai: "", anthropic: "", groq: "" };
    }
  });
  const [isKeyVisible, setIsKeyVisible] = useState(false);
  const [saveStatus, setSaveStatus] = useState<"idle" | "saved" | "cleared">("idle");
  const [activeInstructionTab, setActiveInstructionTab] = useState<"gemini" | "openai" | "anthropic" | "groq">("gemini");

  // Custom high-resolution customizable images
  const [rinImageUrl, setRinImageUrl] = useState(() => {
    try {
      return localStorage.getItem("user_rin_image_url") || "https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&q=80&w=450&h=450";
    } catch {
      return "https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&q=80&w=450&h=450";
    }
  });

  const [aliceImageUrl, setAliceImageUrl] = useState(() => {
    try {
      return localStorage.getItem("user_alice_image_url") || "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&q=80&w=450&h=450";
    } catch {
      return "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&q=80&w=450&h=450";
    }
  });

  const [rinImgBroken, setRinImgBroken] = useState(false);
  const [aliceImgBroken, setAliceImgBroken] = useState(false);

  // Real-time detailed logs stream for transparent PDF parsing
  const [liveLogs, setLiveLogs] = useState<{ id: string; msg: string; type: "info" | "success" | "work" | "warning"; time: string }[]>([]);

  const thoughtsBySubject = {
    Physics: [
      "Compiling radioactive decay kinematics...",
      "Converting electromagnetic vector field symbols...",
      "Formulating circular motion angular velocity equations...",
      "Drafting detailed mechanics work-energy explanations...",
      "Confirming friction coefficients are perfectly aligned with NTA standards.",
      "Applying vector cross product integrations... Success!",
      "Translating complex coordinate pulleys into dynamic mathematical nodes."
    ],
    Chemistry: [
      "Organizing Benzene-ring organic substitution mechanism logs...",
      "Checking periodic trends for electronegative stability limits...",
      "Verifying Gibbs free energy calculations for correctness...",
      "Polishing IUPAC nomenclature spelling for coordinate compounds...",
      "Resolving molecular kinetics half-life reaction rates...",
      "Parsing chemical gas equilibria coefficients: Kp and Kc values...",
      "Isolating stoichiometry atomic mass ratios... Match found!"
    ],
    Mathematics: [
      "Unpacking double-integration definite calculus bounds...",
      "Converting 3-dimensional vector direction cosines to display LaTeX...",
      "Verifying binomial sequence coefficient expansions...",
      "Translating trigonometric identity functions with high-precision ratios...",
      "Deducing limits-continuity differentiability bounds...",
      "Assembling coordinate matrix determinant column vectors...",
      "Formatting conic section tangents and hyperbola equations."
    ]
  };

  const [subjectProgress, setSubjectProgress] = useState<{
    Physics: "idle" | "running" | "done" | "empty" | "error";
    Chemistry: "idle" | "running" | "done" | "empty" | "error";
    Mathematics: "idle" | "running" | "done" | "empty" | "error";
  }>({
    Physics: "idle",
    Chemistry: "idle",
    Mathematics: "idle",
  });

  const [extractedCount, setExtractedCount] = useState<{
    Physics: number;
    Chemistry: number;
    Mathematics: number;
  }>({ Physics: 0, Chemistry: 0, Mathematics: 0 });

  const [aliceAction, setAliceAction] = useState<"cheering" | "ramen" | "sleeping" | "boba" | "peace">("cheering");
  const [aliceDialogue, setAliceDialogue] = useState("Let's do this, Rin-chan! We're hand-crafting a gorgeous mock test! ✨");
  const [rinDialogue, setRinDialogue] = useState("Calibrated coordinates. Ready to convert PDF layout grids.");

  useEffect(() => {
    if (!isLoading) {
      setRinDialogue("Calibrated coordinates. Ready to convert PDF layout grids.");
      setAliceDialogue("Let's do this, Rin-chan! We're hand-crafting a gorgeous mock test! ✨");
      setAliceAction("cheering");
      return;
    }

    const timer = setInterval(() => {
      // Determine active subject
      let activeSubj: "Physics" | "Chemistry" | "Mathematics" | "idle" = "idle";
      if (subjectProgress.Physics === "running") activeSubj = "Physics";
      else if (subjectProgress.Chemistry === "running") activeSubj = "Chemistry";
      else if (subjectProgress.Mathematics === "running") activeSubj = "Mathematics";

      // 1. Pick Alice random action
      const actions: ("cheering" | "ramen" | "sleeping" | "boba" | "peace")[] = ["cheering", "ramen", "sleeping", "boba", "peace"];
      const nextAction = actions[Math.floor(Math.random() * actions.length)];
      setAliceAction(nextAction);

      // 2. Pick Alice dialogue matching her new action
      const aPool = ALICE_DIALOGUE_POOL[nextAction];
      const nextAliceDial = aPool[Math.floor(Math.random() * aPool.length)];
      setAliceDialogue(nextAliceDial);

      // 3. Pick Rin dialogue matching active subject
      const rPool = RIN_DIALOGUE_POOL[activeSubj];
      const nextRinDial = rPool[Math.floor(Math.random() * rPool.length)];
      setRinDialogue(nextRinDial);
    }, 3800);

    return () => clearInterval(timer);
  }, [isLoading, subjectProgress.Physics, subjectProgress.Chemistry, subjectProgress.Mathematics]);

  const handleSaveApiKey = () => {
    try {
      localStorage.setItem("user_gemini_api_key", apiKeys.gemini.trim());
      localStorage.setItem("user_openai_api_key", apiKeys.openai.trim());
      localStorage.setItem("user_anthropic_api_key", apiKeys.anthropic.trim());
      localStorage.setItem("user_groq_api_key", apiKeys.groq.trim());
      localStorage.setItem("user_rin_image_url", rinImageUrl.trim());
      localStorage.setItem("user_alice_image_url", aliceImageUrl.trim());
      setSaveStatus("saved");
      setTimeout(() => setSaveStatus("idle"), 3500);
    } catch (e) {
      console.warn("Could not save settings locally:", e);
    }
  };

  const handleClearApiKey = () => {
    try {
      localStorage.removeItem("user_gemini_api_key");
      localStorage.removeItem("user_openai_api_key");
      localStorage.removeItem("user_anthropic_api_key");
      localStorage.removeItem("user_groq_api_key");
      localStorage.removeItem("user_rin_image_url");
      localStorage.removeItem("user_alice_image_url");
      setApiKeys({ gemini: "", openai: "", anthropic: "", groq: "" });
      setRinImageUrl("https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&q=80&w=450&h=450");
      setAliceImageUrl("https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&q=80&w=450&h=450");
      setSaveStatus("cleared");
      setTimeout(() => setSaveStatus("idle"), 3500);
    } catch (e) {
      console.warn("Could not remove custom keys:", e);
    }
  };

  const tips = [
    "Gemini is reading the PDF... Analyzing atomic orbital equations!",
    "Extracting questions... Setting up Physics & Electromagnetic vector variables.",
    "Formulating structured assessment layouts of Physics, Chemistry & Math sections.",
    "Converting scribbled math structures into clean display LaTeX elements...",
    "Creating step-by-step model answers and solutions for the analytics dashboard!",
  ];

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type === "application/pdf") {
        processPdfFile(file);
      } else {
        setErrorMsg("Please upload a valid PDF file. Images & documents are not supported.");
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processPdfFile(e.target.files[0]);
    }
  };

  const selectPreset = () => {
    setIsLoading(true);
    setLoadingStep("Extracting standard calibration elements...");
    setFileName("Benchmark JEE Mains Syllabus Mock Test");
    
    setTimeout(() => {
      onTestLoaded("Prescribed Benchmark JEE Mains syllabus Mock Test", PRESET_MOCK_TEST);
      setIsLoading(false);
    }, 1200);
  };

  const processPdfFile = async (file: File) => {
    setFileName(file.name);
    setErrorMsg("");
    setIsLoading(true);
    setSubjectProgress({
      Physics: "idle",
      Chemistry: "idle",
      Mathematics: "idle",
    });
    setExtractedCount({ Physics: 0, Chemistry: 0, Mathematics: 0 });

    let progressIdx = 0;
    setLoadingStep(tips[progressIdx]);

    // Interval to cycle through loading messages with user friendly indicators
    const interval = setInterval(() => {
      progressIdx = (progressIdx + 1) % tips.length;
      setLoadingStep(tips[progressIdx]);
    }, 4500);

    // Initial logs setup
    setLiveLogs([]);
    const bootMessages = [
      { text: "🤖 StudyBot core online! Calibrating AI neural networks...", type: "info" as const },
      { text: `📖 Loaded PDF document: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`, type: "success" as const },
      { text: "⚡ Handshaking with Google Gemini Flash models...", type: "info" as const },
      { text: "🎯 Calibrating OCR coordinate mapping vectors for Physics, Chemistry & Math sections...", type: "info" as const }
    ];

    bootMessages.forEach((bm, i) => {
      setTimeout(() => {
        const now = new Date();
        const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
        setLiveLogs(prev => [
          { id: `boot-${i}-${Math.random()}`, msg: bm.text, type: bm.type, time: timeStr },
          ...prev
        ]);
      }, i * 200);
    });

    let thoughtTimer: NodeJS.Timeout | null = null;
    let usedThoughts = new Set<string>();

    const startThoughtGenerator = (subj: "Physics" | "Chemistry" | "Mathematics") => {
      if (thoughtTimer) clearInterval(thoughtTimer);
      
      setTimeout(() => {
        const now = new Date();
        const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
        setLiveLogs(prev => [
          { id: `start-${subj}-${Math.random()}`, msg: `🚀 Working on ${subj} Section: Transmitting page vectors to Gemini AI...`, type: "work", time: timeStr },
          ...prev
        ]);
      }, 50);

      thoughtTimer = setInterval(() => {
        const pool = thoughtsBySubject[subj];
        let available = pool.filter(t => !usedThoughts.has(t));
        if (available.length === 0) {
          usedThoughts.clear();
          available = pool;
        }
        const chosen = available[Math.floor(Math.random() * available.length)];
        usedThoughts.add(chosen);

        const now = new Date();
        const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
        setLiveLogs(prev => [
          { id: `thought-${subj}-${Math.random()}`, msg: `⚙️ [${subj}] StudyBot: ${chosen}`, type: "work", time: timeStr },
          ...prev
        ]);
      }, 3500);
    };

    try {
      // Step 1: Read PDF file as Base64 in standard FileReader interface
      const base64Data = await readPdfAsBase64(file);

      const subjects = [
        { name: "Physics", prefix: "P" },
        { name: "Chemistry", prefix: "C" },
        { name: "Mathematics", prefix: "M" },
      ];

      let allQuestions: Question[] = [];
      let testTitle = "";

      // Step 2: Sequentially process each segment to secure clean, full papers
      const userCustomKey = (() => {
        try {
          return localStorage.getItem("user_gemini_api_key") || "";
        } catch {
          return "";
        }
      })();

      for (const subj of subjects) {
        setSubjectProgress((prev) => ({ ...prev, [subj.name]: "running" }));
        startThoughtGenerator(subj.name as "Physics" | "Chemistry" | "Mathematics");
        
        try {
          const response = await fetch("/api/parse-pdf", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              ...(userCustomKey ? { "x-gemini-api-key": userCustomKey } : {}),
            },
            body: JSON.stringify({
              pdfData: base64Data,
              filename: file.name,
              subject: subj.name,
              prefix: subj.prefix,
            }),
          });

          if (thoughtTimer) {
            clearInterval(thoughtTimer);
            thoughtTimer = null;
          }

          if (!response.ok) {
            throw new Error(`Failed to extract ${subj.name}`);
          }

          const parsedData = await response.json();
          if (parsedData.testName && !testTitle) {
            testTitle = parsedData.testName;
          }

          const questions = parsedData.questions || [];
          const now = new Date();
          const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });

          if (questions.length > 0) {
            const validated = questions.map((q: any, idx: number) => {
              const validId = q.id || `${subj.prefix}-${String(idx + 1).padStart(2, "0")}`;
              const validSection = q.section || (idx < 20 ? "Section A" : "Section B");
              return {
                ...q,
                id: validId,
                subject: subj.name,
                section: validSection,
                questionNumber: q.questionNumber || (idx + 1),
                questionText: q.questionText,
                options: q.options || [],
                correctAnswer: String(q.correctAnswer).trim(),
                topic: q.topic || "General Concepts",
                difficulty: q.difficulty || "Medium",
                explanation: q.explanation || "No explanation parsed.",
              };
            });

            allQuestions = [...allQuestions, ...validated];
            setExtractedCount((prev) => ({ ...prev, [subj.name]: validated.length }));
            setSubjectProgress((prev) => ({ ...prev, [subj.name]: "done" }));

            setLiveLogs(prev => [
              { id: `success-${subj.name}-${Math.random()}`, msg: `✅ Done! Successfully extracted ${validated.length} questions for ${subj.name}.`, type: "success", time: timeStr },
              ...prev
            ]);
          } else {
            setSubjectProgress((prev) => ({ ...prev, [subj.name]: "empty" }));
            setLiveLogs(prev => [
              { id: `empty-${subj.name}-${Math.random()}`, msg: `⚠️ Completed scan of ${subj.name} section but found zero question components.`, type: "warning", time: timeStr },
              ...prev
            ]);
          }
        } catch (err) {
          if (thoughtTimer) {
            clearInterval(thoughtTimer);
            thoughtTimer = null;
          }
          console.error(`Error parsing ${subj.name}:`, err);
          setSubjectProgress((prev) => ({ ...prev, [subj.name]: "error" }));

          const now = new Date();
          const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
          setLiveLogs(prev => [
            { id: `error-${subj.name}-${Math.random()}`, msg: `❌ Request to process ${subj.name} returned an error. Moving to next topic...`, type: "warning", time: timeStr },
            ...prev
          ]);
        }
      }

      if (thoughtTimer) {
        clearInterval(thoughtTimer);
        thoughtTimer = null;
      }

      clearInterval(interval);

      if (allQuestions.length === 0) {
        throw new Error("No readable questions could be extracted from any section in this PDF. Is this a math-based Mock Test PDF?");
      }

      const finalNow = new Date();
      const finalTimeStr = finalNow.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
      setLiveLogs(prev => [
        { id: `finish-${Math.random()}`, msg: `🎉 All completed! Extracted a total of ${allQuestions.length} questions. Initiating CBT engine mockup...`, type: "success", time: finalTimeStr },
        ...prev
      ]);

      // Briefly pause so the user sees the completed states
      await new Promise((resolve) => setTimeout(resolve, 1500));
      onTestLoaded(testTitle || file.name, allQuestions);
    } catch (error: any) {
      console.error(error);
      setErrorMsg(error.message || "An unexpected error occurred during document translation.");
    } finally {
      if (thoughtTimer) {
        clearInterval(thoughtTimer);
      }
      clearInterval(interval);
      setIsLoading(false);
    }
  };

  const readPdfAsBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const resultString = reader.result as string;
        const base64 = resultString.split(",")[1];
        resolve(base64);
      };
      reader.onerror = (error) => reject(error);
      reader.readAsDataURL(file);
    });
  };

  const triggerFileSelect = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="max-w-6xl w-full mx-auto py-8 px-4 md:px-6 select-none">
      <div className="text-center mb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-50 text-blue-700 text-xs font-bold rounded-full mb-3 shadow-xs border border-blue-100">
          <BookOpen size={12} />
          <span>JEE MAINS CBT REPLICA ENGINE</span>
        </div>
        <h1 className="text-3xl font-black text-slate-800 tracking-tight sm:text-4xl">
          JEE Mains CBT Mock Test Simulator
        </h1>
        <p className="mt-3 text-slate-500 max-w-xl mx-auto text-sm leading-relaxed">
          Upload any paper PDF — Gemini AI automatically extracts complex diagrams, options, and math formulas with LaTeX, instantly deploying an authentic CBT Test replica.
        </p>

        {/* IMPORTANT USER BULLETINS (DISCLAIMER & ANSWER-KEY GUARANTEE) */}
        <div className="mt-5 max-w-2xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-3 text-left">
          <div className="p-3 bg-amber-50/75 border border-amber-200/60 rounded-xl shadow-2xs">
            <p className="text-[11px] text-amber-900 leading-relaxed font-semibold">
              <span className="text-xs mr-1">⚠️</span>
              <strong>NTA Disclaimer:</strong> This platform is an independent simulation tool and is <strong>not connected to NTA (National Testing Agency) in any manner</strong>.
            </p>
          </div>
          <div className="p-3 bg-emerald-50/75 border border-emerald-200/60 rounded-xl shadow-2xs">
            <p className="text-[11px] text-emerald-900 leading-relaxed font-semibold">
              <span className="text-xs mr-1">✨</span>
              <strong>No Answer Key?</strong> Absolutely no problem! The platform will <strong>auto-generate precise keys and solutions</strong> automatically.
            </p>
          </div>
        </div>
      </div>

      {/* AI KEY & DEVELOPER STORY HUB */}
      <div className="mb-10 max-w-6xl w-full mx-auto">
        <div className="bg-slate-50 rounded-2xl border-2 border-slate-200/80 overflow-hidden shadow-sm flex flex-col">
          
          {/* HEADER CO-PILOT WITH EMBEDDED TOGGLE CARD */}
          <div className="bg-linear-to-r from-slate-800 to-indigo-950 p-5 md:p-6 text-white text-left relative overflow-hidden select-none">
            {/* Subtle floating background patterns */}
            <div className="absolute top-0 right-1/4 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />
            
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
              <div className="space-y-1.5 flex-1 select-text">
                <span className="inline-block text-[10px] font-black tracking-widest text-indigo-300 uppercase bg-indigo-950/60 px-2.5 py-1 rounded border border-indigo-800">
                  🎓 PERSISTENT SECURE FUEL BOARD
                </span>
                <h2 className="text-xl font-extrabold tracking-tight text-white flex items-center gap-2">
                  <span>🚀</span>
                  <span>Developer's Desk & Dedicated API Fuel Hub</span>
                </h2>
                <p className="text-xs text-indigo-200 font-medium">
                  A middle-class student's answer to expensive test series. Bring your own free key to enjoy unlimited fast PDF mock parsing!
                </p>
              </div>
              
              <button
                type="button"
                onClick={() => setShowApiKeySettings(!showApiKeySettings)}
                className="shrink-0 px-3 py-1.5 bg-white/10 hover:bg-white/20 border border-white/20 text-xs font-bold rounded-lg text-white transition flex items-center gap-1 cursor-pointer self-start sm:self-center"
              >
                <Settings size={13} className="animate-pulse" />
                <span>{showApiKeySettings ? "Collapse Panel ▲" : "Expand Settings ▼"}</span>
              </button>
            </div>
          </div>

          {showApiKeySettings && (
            <div className="p-5 md:p-6 bg-white text-left text-xs select-text space-y-6">
              
              {/* SECTION 1: THE DEVELOPER'S STORY (JEE 94-PERCENTILER'S MISSION) */}
              <div className="bg-[#f8fafc] border border-slate-200/60 p-4 rounded-xl flex flex-col md:flex-row gap-4 items-start relative overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-xl pointer-events-none" />
                <div className="absolute bottom-0 right-10 w-16 h-16 bg-blue-500/5 rounded-full blur-xl pointer-events-none" />
                
                {/* Developer Persona Badge */}
                <div className="shrink-0 bg-linear-to-br from-amber-50 to-orange-100 border border-amber-200 w-12 h-12 rounded-xl flex flex-col items-center justify-center shadow-xs select-none">
                  <span className="text-sm font-black text-amber-600">JEE</span>
                  <span className="text-[10px] font-extrabold text-amber-700 leading-none">94%ile</span>
                </div>
                
                <div className="flex-1 space-y-2">
                  <h3 className="font-extrabold text-slate-800 text-[13px] flex items-center gap-1.5 select-none">
                    <span>👑</span>
                    <span>The 94th Percentile Mission (From Your Developer's Desk)</span>
                  </h3>
                  <div className="text-slate-600 space-y-2 text-[11.5px] leading-relaxed">
                    <p>
                      Hey there, fellow aspirants! I am the creator of this platform. Like you, I put my blood, sweat, and tears into preparing for <strong>JEE Mains</strong> and secured a <strong>94 percentile</strong>. During my exam grind, I noticed a huge gap: there is literally a goldmine of <strong>completely free, abandoned Mock Test PDFs</strong> lying on Telegram channels and forums, but doing mock tests on a flat paper PDF is incredibly static. What we truly need is an authentic screen-based simulator experience, step-by-step solutions with real calculations, and comprehensive diagnostics. But premium CBT test series charge thousands of rupees, which is out of reach for many.
                    </p>
                    <p>
                      This simulator is my solution to that. It instantly parses <strong>any free or abandoned PDF</strong>, reads complicated diagrams/chemistry nomenclature, formats mathematical expressions using beautiful <strong>LaTeX</strong>, and launches an absolutely precise NTA-style CBT test panel with fully detailed explanations and analysis metrics on-the-fly!
                    </p>
                    <p>
                      <strong>The Rate Limit & Budget Bottleneck:</strong> Because I am from a modest, middle-class family, I cannot afford a paid premium API key that bills me for every usage. The embedded key I have supplied is on Google's <strong>Free Tier</strong>. This free key is shared globally and is restricted by Google to handle a maximum of 2-3 requests per minute. If more than 5 to 10 students use it at the same time, it bottlenecks, rate-limits, or crashes. To ensure a 100% dedicated, independent, and blazing fast experience, I highly urge you to grab your own free key!
                    </p>
                  </div>
                </div>
              </div>

              {/* SECTION 2: ARCHITECTURE & PRIVACY GUARANTEE */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-indigo-50/50 border border-indigo-100 rounded-xl space-y-2">
                  <h4 className="font-extrabold text-indigo-950 text-xs flex items-center gap-1.5 select-none">
                    <span>🛡️</span>
                    <span>No Database! 100% Saved on Local Storage</span>
                  </h4>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    This platform values your privacy. <strong>Absolutely everything is stored locally on your device!</strong> There is no central database. Your custom API keys, past uploaded mock tests, historical attempts, and diagnostic scorecards are kept entirely inside your own browser cache (localStorage). It is completely secure.
                  </p>
                </div>
                <div className="p-4 bg-amber-50/70 border border-amber-200/60 rounded-xl space-y-2">
                  <h4 className="font-extrabold text-amber-800 text-xs flex items-center gap-1.5 select-none">
                    <span>⚠️</span>
                    <span>Safety Warning & anti-Leak Disclaimer</span>
                  </h4>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    Your API keys are stored 100% locally inside your browser cache. However, <strong>please note that the developer is not responsible if, due to your own oversight or mistakes</strong> (such as taking screen recordings showing your keys, leaving your session open on public computers in libraries or cyber-cafes, or sharing browser cache exports), your API key gets leaked. Guard your key like a password!
                  </p>
                </div>
              </div>

              {/* SECTION 3: WHAT IS AN API KEY? */}
              <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-2">
                <h4 className="font-extrabold text-slate-800 text-xs flex items-center gap-1 select-none">
                  <span>💡</span>
                  <span>Knowledge Corner: What is an API Key?</span>
                </h4>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  An <strong>API (Application Programming Interface) Key</strong> is a secret code that acts like a private secure keycard. It tells Google or other AI servers that you are a authorized caller, allowing your browser to send PDF pages directly to the AI model-brain to receive LaTeX translations. By putting your own key, Google assigns you a **100% isolated, dedicated free-tier quota** with zero central bottlenecks!
                </p>
              </div>

              {/* SECTION 4: OPTIONS & GUIDE FOR DIFFERENT AIs */}
              <div className="space-y-3.5 pt-2">
                <label className="block text-xs font-extrabold text-slate-800 select-none">
                  🔍 Choose AI Provider for Instructions & Step-by-Step Setup:
                </label>
                
                {/* Tabs */}
                <div className="flex flex-wrap gap-1.5 border-b border-slate-100 pb-2 select-none">
                  {[
                    { id: "gemini", label: "Google Gemini (Free & Recommended) ✨", activeColor: "bg-blue-600 text-white border-blue-600" },
                    { id: "openai", label: "OpenAI GPT-4", activeColor: "bg-emerald-600 text-white border-emerald-600" },
                    { id: "anthropic", label: "Anthropic Claude", activeColor: "bg-amber-600 text-white border-amber-600" },
                    { id: "groq", label: "Groq / DeepSeek", activeColor: "bg-indigo-600 text-white border-indigo-600" }
                  ].map((tab) => {
                    const isActive = activeInstructionTab === tab.id;
                    return (
                      <button
                        key={tab.id}
                        type="button"
                        onClick={() => setActiveInstructionTab(tab.id as any)}
                        className={`px-3 py-1.5 text-[11px] font-bold rounded-lg border cursor-pointer transition-all duration-200 ${
                          isActive 
                            ? tab.activeColor 
                            : "bg-slate-50 hover:bg-slate-100 text-slate-600 border-slate-200 shadow-2xs"
                        }`}
                      >
                        {tab.label}
                      </button>
                    );
                  })}
                </div>

                {/* Tab content */}
                <div className="bg-[#fefaf6]/50 p-4 rounded-xl border border-orange-100/60 mt-2 text-[11.5px] leading-relaxed text-slate-600">
                  
                  {activeInstructionTab === "gemini" && (
                    <div className="space-y-2">
                      <div className="font-extrabold text-slate-800 flex items-center gap-1.5 text-xs uppercase tracking-tight">
                        <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                        <span>Google Gemini API Key (100% Free - Highly Recommended)</span>
                      </div>
                      <p>
                        Google AI Studio grants students an incredibly generous, **permanently free API quota** (up to 15 Requests Per Minute)! It processes full PDF documents with robust LaTeX equations at ₹0 cost.
                      </p>
                      <div className="bg-white/80 rounded-lg p-3 border border-slate-200/50 space-y-1.5 text-slate-700">
                        <p className="font-black text-[11px] uppercase tracking-wider text-slate-500">Step-by-Step setup:</p>
                        <ol className="list-decimal list-inside space-y-1.5 text-xs font-medium">
                          <li>
                            Open <a href="https://aistudio.google.com/" target="_blank" rel="noopener noreferrer" className="text-blue-600 font-extrabold hover:underline">Google AI Studio (aistudio.google.com)</a> in a new tab and sign in using your standard Gmail.
                          </li>
                          <li>
                            Click the blue **"Get API key"** button on the side panel or navigation header.
                          </li>
                          <li>
                            Select **"Create API Key"** and choose to generate it in a new or default project.
                          </li>
                          <li>
                            Copy your secret key string (usually starting with <code className="font-mono bg-slate-100 px-1 py-[1.5px] text-slate-800 select-all rounded font-bold">AIzaSy...</code>).
                          </li>
                          <li>
                            Paste this key into the field below and click **"Save Settings"**!
                          </li>
                        </ol>
                      </div>
                    </div>
                  )}

                  {activeInstructionTab === "openai" && (
                    <div className="space-y-2">
                      <div className="font-extrabold text-slate-800 flex items-center gap-1.5 text-xs uppercase tracking-tight">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                        <span>OpenAI GPT-4 API Key Instructions</span>
                      </div>
                      <p>
                        OpenAI produces incredible accuracy through GPT-4o models. However, **OpenAI does not offer a free tier API**; they require users to deposit a minimum $5 prepaid balance inside their platform to make requests.
                      </p>
                      <div className="bg-white/80 rounded-lg p-3 border border-slate-200/50 space-y-1.5 text-slate-700">
                        <p className="font-black text-[11px] uppercase tracking-wider text-slate-500">Step-by-Step setup:</p>
                        <ol className="list-decimal list-inside space-y-1.5 text-xs font-medium">
                          <li>Sign in at the <a href="https://platform.openai.com/" target="_blank" rel="noopener noreferrer" className="text-blue-600 font-extrabold hover:underline">OpenAI Platform (platform.openai.com)</a>.</li>
                          <li>Navigate to the "Billing" panel and add a minimum prepaid balance (e.g., $5).</li>
                          <li>Go to the "API Keys" section, create a secret key (prefix <code className="bg-slate-100 font-mono px-1">sk-proj-...</code>), and copy it.</li>
                        </ol>
                      </div>
                      <div className="p-2.5 bg-amber-50 border border-amber-100 text-amber-900 rounded-lg text-[10.5px] font-bold">
                        ⚠️ Recommendation: Since our server-side compiler is specifically aligned to parse PDF base64 payloads using Google Gemini’s zero-cost API, you should generate a completely free Gemini API key instead!
                      </div>
                    </div>
                  )}

                  {activeInstructionTab === "anthropic" && (
                    <div className="space-y-2">
                      <div className="font-extrabold text-slate-800 flex items-center gap-1.5 text-xs uppercase tracking-tight">
                        <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                        <span>Anthropic Claude API Key Instructions</span>
                      </div>
                      <p>
                        Anthropic's Claude 3.5 Sonnet is highly praised for deep logical explanation code. Like OpenAI, Anthropic **does not provide a permanently free API key** without credit card deposition and usage rates.
                      </p>
                      <div className="bg-white/80 rounded-lg p-3 border border-slate-200/50 space-y-1.5 text-slate-700">
                        <p className="font-black text-[11px] uppercase tracking-wider text-slate-500">Step-by-Step setup:</p>
                        <ol className="list-decimal list-inside space-y-1.5 text-xs font-medium">
                          <li>Go to the <a href="https://console.anthropic.com/" target="_blank" rel="noopener noreferrer" className="text-blue-600 font-extrabold hover:underline">Anthropic Console (console.anthropic.com)</a>.</li>
                          <li>Verify details and add credit balance under the "Billing" sections.</li>
                          <li>Generate your key (prefix <code className="bg-slate-100 font-mono px-1">sk-ant-...</code>).</li>
                        </ol>
                      </div>
                      <div className="p-2.5 bg-amber-50 border border-amber-100 text-amber-900 rounded-lg text-[10.5px] font-bold">
                        💡 Tip: Simply use Google Gemini! It has no setup barriers, requires no deposit, and parses LaTeX perfectly under the ₹0 free-tier limit.
                      </div>
                    </div>
                  )}

                  {activeInstructionTab === "groq" && (
                    <div className="space-y-2">
                      <div className="font-extrabold text-slate-800 flex items-center gap-1.5 text-xs uppercase tracking-tight">
                        <span className="w-2.5 h-2.5 rounded-full bg-indigo-500" />
                        <span>Groq & DeepSeek API Integration Details</span>
                      </div>
                      <p>
                        Groq is widely known for ultra-high-speed processing of open weights like Llama and Mixtral. DeepSeek is highly competitive but handles multimodal file uploads differently.
                      </p>
                      <div className="bg-white/80 rounded-lg p-3 border border-slate-200/50 space-y-1.5 text-slate-700">
                        <p className="font-black text-[11px] uppercase tracking-wider text-slate-500">Step-by-Step setup:</p>
                        <ol className="list-decimal list-inside space-y-1.5 text-xs font-medium">
                          <li>Go to the <a href="https://console.groq.com/" target="_blank" rel="noopener noreferrer" className="text-blue-600 font-extrabold hover:underline">Groq Console (console.groq.com)</a>.</li>
                          <li>Navigate to the API Keys sidebar and generate your key (prefix <code className="bg-slate-100 font-mono px-1">gsk_...</code>).</li>
                        </ol>
                      </div>
                      <div className="p-2.5 bg-indigo-50 border border-indigo-100 text-slate-700 rounded-lg text-[10.5px] font-medium">
                        💡 Since the main compiler uses Google Gemini under-the-hood to securely format LaTeX coordinates, we recommend putting your **Google Gemini keys** below to process mock papers correctly!
                      </div>
                    </div>
                  )}

                </div>
              </div>

              {/* SECTION 5: INPUT FORM & AVATAR CONFIG */}
              <div className="space-y-4 pt-4 border-t border-slate-200">
                <div className="space-y-1.5 text-left">
                  <label className="block text-xs font-extrabold text-slate-800 flex items-center gap-1">
                    <span>🗝️</span> {
                      activeInstructionTab === "gemini" ? "Enter Your Actionable Gemini API Key:" :
                      activeInstructionTab === "openai" ? "Enter Your Actionable OpenAI GPT-4 API Key:" :
                      activeInstructionTab === "anthropic" ? "Enter Your Actionable Anthropic Claude API Key:" :
                      "Enter Your Actionable Groq / DeepSeek API Key:"
                    }
                  </label>
                  <div className="relative">
                    <input
                      type={isKeyVisible ? "text" : "password"}
                      value={apiKeys[activeInstructionTab] || ""}
                      onChange={(e) => {
                        const val = e.target.value;
                        setApiKeys(prev => ({
                          ...prev,
                          [activeInstructionTab]: val
                        }));
                      }}
                      placeholder={
                        activeInstructionTab === "gemini" ? "AIzaSy... (Plug Gemini key here to bypass rate limits)" :
                        activeInstructionTab === "openai" ? "sk-proj-... (Enter your OpenAI API key)" :
                        activeInstructionTab === "anthropic" ? "sk-ant-... (Enter your Anthropic Claude key)" :
                        "gsk_... (Enter your Groq API key)"
                      }
                      className="w-full px-3 py-2.5 pr-10 border-2 border-slate-200 rounded-lg font-mono text-xs focus:border-indigo-500 focus:outline-hidden text-slate-850 bg-white shadow-xs focus:ring-1 focus:ring-indigo-500"
                    />
                    <button
                      type="button"
                      onClick={() => setIsKeyVisible(!isKeyVisible)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 p-0.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      {isKeyVisible ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  </div>
                </div>

                {/* Avatar Customization Block */}
                <div className="pt-3 border-t border-slate-200 space-y-3">
                  <h4 className="font-bold text-slate-800 text-xs flex items-center gap-1.5 select-none text-left">
                    <span>🌸</span>
                    <span>Customize Live Anime Parsing Companions</span>
                  </h4>
                  <p className="text-slate-505 text-[11px] leading-relaxed select-none text-left">
                    Give customized personal face details to our compiler study space! Paste any high-resolution image URL to instantly custom render Rin-chan and Alice-chan.
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                    <div className="space-y-1 text-left">
                      <label className="block text-[11px] font-bold text-slate-600 flex items-center gap-1">
                        <span>🧠</span> Rin (Black Hair/Dev) URL:
                      </label>
                      <input
                        type="text"
                        value={rinImageUrl}
                        onChange={(e) => setRinImageUrl(e.target.value)}
                        placeholder="Paste image web address (https://...)"
                        className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md text-[11px] focus:ring-1 focus:ring-blue-500 focus:outline-hidden text-slate-700 bg-white"
                      />
                    </div>
                    <div className="space-y-1 text-left">
                      <label className="block text-[11px] font-bold text-slate-600 flex items-center gap-1">
                        <span>📣</span> Alice (Blonde Hair/AI) URL:
                      </label>
                      <input
                        type="text"
                        value={aliceImageUrl}
                        onChange={(e) => setAliceImageUrl(e.target.value)}
                        placeholder="Paste image web address (https://...)"
                        className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md text-[11px] focus:ring-1 focus:ring-blue-500 focus:outline-hidden text-slate-700 bg-white"
                      />
                    </div>
                  </div>
                </div>

                {/* Save and Reset Commands */}
                <div className="flex gap-2 justify-end pt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={handleSaveApiKey}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs rounded-lg transition-all flex items-center gap-1.5 shadow-md shadow-indigo-200 cursor-pointer hover:scale-[1.01]"
                  >
                    {saveStatus === "saved" ? (
                      <>
                        <Check size={13} strokeWidth={3} />
                        <span>All Changes Saved!</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle size={13} />
                        <span>Save Settings</span>
                      </>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={handleClearApiKey}
                    className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs rounded-lg transition cursor-pointer"
                  >
                    Reset Defaults
                  </button>
                </div>

                {saveStatus === "saved" && (
                  <p className="text-[10.5px] text-emerald-600 font-bold flex items-center gap-1.5 py-2 bg-emerald-50 border border-emerald-100 px-3 rounded-lg text-left shadow-2xs">
                    ✓ Configuration saved successfully! Your dedicated API Key will now handle all upcoming mock translations with massive speed, completely separate from global limits.
                  </p>
                )}
                {saveStatus === "cleared" && (
                  <p className="text-[10.5px] text-indigo-700 font-bold flex items-center gap-1.5 py-2 bg-indigo-50 border border-indigo-100 px-3 rounded-lg text-left shadow-2xs">
                    ✓ Custom configurations deleted. System will revert back to the developer's default public key and anime graphic presets.
                  </p>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {errorMsg && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 text-xs flex items-start gap-2.5 shadow-sm animate-shake">
          <AlertCircle size={16} className="shrink-0 mt-0.5 text-red-500" />
          <div className="flex-1">
            <span className="font-bold">Extraction Error:</span> {errorMsg}
          </div>
        </div>
      )}

      {isLoading ? (
        <div className="bg-linear-to-b from-amber-50/40 via-white to-orange-50/20 rounded-2xl border-2 border-amber-200/80 p-6 md:p-8 text-center shadow-xl relative overflow-hidden select-none text-slate-800 min-h-[460px]">
          {/* Custom style injection for high-performance pure-CSS animations */}
          <style>{`
            @keyframes scan-beam {
              0%, 100% { top: 0%; opacity: 0.8; }
              50% { top: 100%; opacity: 0.8; }
            }
            @keyframes bounce-cozy {
              0%, 100% { transform: translateY(0); }
              50% { transform: translateY(-8px); }
            }
            @keyframes float-cozy {
              0%, 100% { transform: translateY(0); }
              50% { transform: translateY(-5px); }
            }
            @keyframes pulse-cozy {
              0%, 100% { transform: scale(3D); }
              50% { transform: scale(1.03); }
            }
            @keyframes tilt-cozy {
              0%, 100% { transform: rotate(0deg); }
              50% { transform: rotate(3deg); }
            }
            @keyframes float-particle {
              0% { transform: translateY(15px) translateX(0px); opacity: 0; }
              40% { opacity: 0.95; }
              80% { opacity: 0.95; }
              100% { transform: translateY(-60px) translateX(var(--float-x, 15px)); opacity: 0; }
            }
            @keyframes rise-steam {
              0% { transform: translateY(0) scale(0.9); opacity: 0; }
              50% { opacity: 0.7; }
              100% { transform: translateY(-15px) scale(1.15); opacity: 0; }
            }
          `}</style>

          {/* Growing Ambient Background Circles */}
          <div className="absolute top-0 left-1/4 w-72 h-72 bg-amber-500/5 rounded-full blur-[100px] pointer-events-none" />
          <div className="absolute bottom-0 right-1/4 w-72 h-72 bg-rose-500/5 rounded-full blur-[100px] pointer-events-none" />

          {/* Cute header layout */}
          <div className="flex flex-col items-center mb-6">
            <div className="text-[10px] font-black text-rose-500 uppercase tracking-widest bg-rose-50 border border-rose-100 px-3 py-1 rounded-full animate-pulse flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />
              Cozy AI Study Room (Parsing in Progress...)
            </div>
            <h3 className="text-base font-black text-slate-800 tracking-tight mt-2 flex items-center gap-1.5">
              <span>🌸</span> Live Test Compiler Room <span>🌸</span>
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5 max-w-sm">
              Rin is compiling the mock paper with Gemini AI while Alice keeps her company!
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch text-left">
            {/* LEFT SIDE: Chat dialogue room (lg:col-span-6) */}
            <div className="lg:col-span-7 bg-white/40 border border-slate-100 rounded-2xl p-4 md:p-5 flex flex-col justify-between min-h-[320px] space-y-4 shadow-xs">
              
              <div className="text-[10px] font-black text-indigo-600 uppercase tracking-widest border-b border-indigo-100/50 pb-1.5 mb-1 select-none">
                💬 AI Compiler Banter chat
              </div>

              {/* REAL-TIME MINI COMIC DIALOGUE FEED */}
              <div className="flex-1 flex flex-col justify-center space-y-4 py-1 select-text">
                
                {/* 1. Rin Dialogue (Interactive) */}
                <div className="flex gap-3 items-start select-text">
                  <div className="shrink-0 flex flex-col items-center select-none">
                    <div className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center overflow-hidden shadow-xs relative">
                      {/* Stylized dark-hair chibi avatar */}
                      <svg viewBox="0 0 35 35" className="w-full h-full">
                        <circle cx="17.5" cy="17.5" r="16" fill="#1e293b" />
                        <circle cx="17.5" cy="19.5" r="9.5" fill="#ffe4e6" />
                        {/* hair */}
                        <path d="M 7,12 Q 17.5,3 28,12 Q 26,16 17.5,13 Q 9,16 7,12" fill="#1e293b" />
                        <circle cx="14" cy="19" r="1.8" fill="#1d4ed8" />
                        <circle cx="21" cy="19" r="1.8" fill="#1d4ed8" />
                        <path d="M 16,24 Q 17.5,25.5 19,24" stroke="#ea580c" strokeWidth="0.8" fill="none" />
                      </svg>
                      {/* Active typing dot badge */}
                      <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-blue-500 rounded-full border border-slate-900 animate-ping" />
                      <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 bg-blue-400 rounded-full border border-slate-900" />
                    </div>
                    <span className="text-[8px] font-black text-slate-500 mt-1 uppercase tracking-tight">Rin (Dev)</span>
                  </div>
                  
                  <div className="flex-1 bg-sky-50 border border-sky-100/80 text-left relative p-2.5 rounded-2xl rounded-tl-sm text-[11px] leading-relaxed text-slate-700 shadow-xs">
                    {/* Tail */}
                    <div className="absolute left-0 top-3 w-1.5 h-1.5 bg-sky-50 border-l border-b border-sky-100 rotate-45 -translate-x-[4.5px]" />
                    <span className="text-[8px] font-black text-sky-600 block mb-0.5 uppercase tracking-wider">⚡ SECTION EXTRACTOR ACTION</span>
                    <p className="font-bold text-slate-800 font-sans">{rinDialogue}</p>
                  </div>
                </div>

                {/* 2. Alice Dialogue (Randomized) */}
                <div className="flex gap-3 items-start flex-row-reverse select-text">
                  <div className="shrink-0 flex flex-col items-center select-none">
                    <div className="w-9 h-9 rounded-full bg-amber-100 border border-amber-300 flex items-center justify-center overflow-hidden shadow-xs relative">
                      {/* Stylized blonde chibi avatar */}
                      <svg viewBox="0 0 35 35" className="w-full h-full">
                        <circle cx="17.5" cy="17.5" r="16" fill="#fef08a" />
                        <circle cx="17.5" cy="19.5" r="9.5" fill="#fff1f2" />
                        <path d="M 7,12 Q 17.5,3 28,12 Q 26,15 17.5,13.5 Q 9,15 7,12" fill="#fde047" />
                        <circle cx="14" cy="19" r="1.8" fill="#0891b2" />
                        <circle cx="21" cy="19" r="1.8" fill="#0891b2" />
                        <path d="M 16,24 Q 17.5,25.5 19,24" stroke="#db2777" strokeWidth="1" fill="none" />
                      </svg>
                      {/* Active icon badge */}
                      <span className="absolute -bottom-0.5 -right-0.5 text-[9px] drop-shadow-xs select-none">
                        {aliceAction === "ramen" ? "🍜" :
                         aliceAction === "sleeping" ? "😴" :
                         aliceAction === "boba" ? "🧋" :
                         aliceAction === "peace" ? "✌️" : "📣"}
                      </span>
                    </div>
                    <span className="text-[8px] font-black text-amber-600 mt-1 uppercase tracking-tight">Alice (AI)</span>
                  </div>
                  
                  <div className="flex-1 bg-amber-50/70 border border-amber-100 text-left relative p-2.5 rounded-2xl rounded-tr-sm text-[11px] leading-relaxed text-slate-700 shadow-xs">
                    {/* Tail */}
                    <div className="absolute right-0 top-3 w-1.5 h-1.5 bg-amber-50/70 border-r border-t border-amber-100 rotate-45 translate-x-[4.5px]" />
                    <span className="text-[8px] font-black text-amber-500 block mb-0.5 uppercase tracking-wider">🌸 COMPANION CHAT</span>
                    <p className="font-semibold text-slate-800 italic">"{aliceDialogue}"</p>
                  </div>
                </div>

              </div>

              {/* Status footer */}
              <div className="text-[9px] text-slate-400 select-none">
                💡 Mini dialogues update reactively in real-time as sections are processed.
              </div>
            </div>

            {/* RIGHT SIDE: Simplified Progress Board (lg:col-span-5) */}
            <div className="lg:col-span-5 flex flex-col justify-between min-h-[320px] space-y-4">
              
              {/* PROGRESS DECK (Clean and easy to digest) */}
              <div className="bg-white/80 border border-amber-100/70 p-3.5 rounded-xl shadow-xs space-y-2 text-xs select-none">
                <div className="text-[10px] font-extrabold text-amber-600 uppercase tracking-widest border-b border-amber-100 pb-1 flex justify-between items-center mb-1">
                  <span>📚 Subject Compiling Board</span>
                  <span className="font-mono bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded font-black">
                    Extracted: {extractedCount.Physics + extractedCount.Chemistry + extractedCount.Mathematics}/75
                  </span>
                </div>
                
                <div className="grid grid-cols-1 gap-2">
                  {[
                    { name: "Physics", count: extractedCount.Physics, label: "Physics (20 MCQs + 5 NATs)", icon: "⚛️" },
                    { name: "Chemistry", count: extractedCount.Chemistry, label: "Chemistry (20 MCQs + 5 NATs)", icon: "🧪" },
                    { name: "Mathematics", count: extractedCount.Mathematics, label: "Mathematics (20 MCQs + 5 NATs)", icon: "📐" }
                  ].map((sub) => {
                    const status = subjectProgress[sub.name as keyof typeof subjectProgress];
                    return (
                      <div key={sub.name} className="flex items-center justify-between py-1.5 px-2 bg-slate-50 border border-slate-100 rounded-md">
                        <div className="flex items-center gap-2">
                          <span className="text-sm select-none">{sub.icon}</span>
                          <span className="font-bold text-slate-700 text-[11px] truncate tracking-tight">{sub.label}</span>
                        </div>
                        
                        <div>
                          {status === "running" && (
                            <span className="text-[9px] bg-amber-100 text-amber-800 border border-amber-200 font-extrabold px-2 py-0.5 rounded-full animate-pulse">
                              Active compile...
                            </span>
                          )}
                          {status === "done" && (
                            <span className="text-[9px] bg-emerald-100 text-emerald-800 border border-emerald-200 font-black px-2 py-0.5 rounded-full flex items-center gap-1">
                              ✓ {sub.count} Questions
                            </span>
                          )}
                          {status === "idle" && (
                            <span className="text-[9px] bg-slate-100 text-slate-400 border border-slate-200 px-2 py-0.5 rounded-full">
                              In Queue
                            </span>
                          )}
                          {status === "error" && (
                            <span className="text-[9px] bg-rose-100 text-rose-500 border border-rose-200 px-2 py-0.5 rounded-full">
                              Failed
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* LIVE COZY FOCUS */}
              <div className="p-3 bg-indigo-50 border border-indigo-100/50 rounded-lg text-left select-none">
                <p className="text-[10px] text-indigo-700 leading-relaxed font-bold flex items-center gap-1.5">
                  <span>💡</span> Live Focus Details: {loadingStep}
                </p>
              </div>

            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-stretch">
          {/* Uploader Card */}
          <div
            className={`md:col-span-7 lg:col-span-8 bg-white rounded-xl border-2 border-dashed ${
              dragActive ? "border-blue-500 bg-blue-50/40" : "border-slate-300 hover:border-slate-400"
            } p-8 flex flex-col items-center justify-center text-center transition cursor-pointer shadow-xs min-h-[350px] relative`}
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            onClick={triggerFileSelect}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf"
              onChange={handleFileChange}
              className="hidden"
            />
            
            <div className="w-12 h-12 rounded-full bg-slate-50 flex items-center justify-center text-slate-500 mb-4 shadow-inner border border-slate-100">
              <Upload size={22} className="text-slate-600" />
            </div>

            <div className="font-bold text-sm text-slate-700">
              Drag & Drop PDF Mock Test File
            </div>
            <p className="text-xs text-slate-400 mt-1.5 max-w-[280px]">
              Supports standard Exam PDFs. Missing an answer key? No problem! The platform will auto-generate keys, marks, and explanations.
            </p>

            <button
              type="button"
              className="mt-5 px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded shadow-md shadow-blue-100 transition cursor-pointer"
            >
              Select PDF File
            </button>
          </div>

          {/* Quick Preset Presets Card */}
          <div className="md:col-span-5 lg:col-span-4 bg-slate-900 text-slate-100 rounded-xl p-6 flex flex-col justify-between shadow-lg border border-slate-800">
            <div>
              <div className="flex items-center gap-1.5 text-blue-400 text-xs font-bold uppercase tracking-wider mb-2">
                <Database size={13} />
                <span>Instant Playgrounds</span>
              </div>
              <h3 className="font-bold text-base text-white tracking-tight">No PDF handy?</h3>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                Experience the exact CBT exam panel immediately with our calibrated premium calibration paper containing questions from recent years.
              </p>

              <div className="mt-5 bg-slate-800/60 p-4 rounded-lg border border-slate-800 select-text">
                <div className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest mb-1.5">Prescribed Syllabus Paper</div>
                <div className="font-semibold text-xs text-white">Full Syllabus Mock Test</div>
                <div className="text-[11px] text-slate-400 mt-1.5 space-y-1">
                  <div>• Physics (MCQ + Numerical key)</div>
                  <div>• Chemistry (MCQ + Numerical key)</div>
                  <div>• Mathematics (MCQ + Numerical key)</div>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={selectPreset}
              className="mt-6 w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 hover:scale-[1.01] text-white font-bold text-xs rounded transition flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-indigo-900/30 active:scale-[0.99]"
            >
              <span>Launch Calibrated Simulator</span>
              <ArrowRight size={13} />
            </button>
          </div>
        </div>
      )}

      {/* Quick guide */}
      <div className="mt-12 border-t pt-8 grid grid-cols-1 md:grid-cols-3 gap-6 text-slate-500 select-text text-xs leading-relaxed">
        <div className="p-4 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-100 transition">
          <h4 className="font-bold text-slate-700 text-[13px] mb-2 flex items-center gap-1.5">
            <span>⚙️</span> Standard NTA CBT Replica
          </h4>
          The engine mimics the exact interface used in real JEE Mains centers, complete with the legend palette indices, timers, instructions, and save workflows.
        </div>
        <div className="p-4 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-100 transition">
          <h4 className="font-bold text-slate-700 text-[13px] mb-2 flex items-center gap-1.5">
            <span>➗</span> Formulas with LaTeX
          </h4>
          Gemini automatically translates complicated mathematical vectors, chemistry stoichiometry elements, and coordinate layouts into clear-drawn math.
        </div>
        <div className="p-4 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-100 transition">
          <h4 className="font-bold text-slate-700 text-[13px] mb-2 flex items-center gap-1.5">
            <span>📊</span> In-Depth Analytics
          </h4>
          Get granular subject statistics, correctness trackers, topic-wise accuracy metrics, and time-overrun diagnostics.
        </div>
      </div>
    </div>
  );
}
export default PdfUploader;
